# Mustanad / مستند — Professional document scanner (Flutter + GetX + SQLite)

المزايا: محرك مسح ذاتي (اكتشاف الحواف، تصحيح المنظور، إزالة الظلال، فلاتر)، كاميرا مع اكتشاف مباشر وتصوير تلقائي،
دفعات متعددة الصفحات، مجلدات ووسوم وبحث ذكي داخل النص، PDF (إنشاء، دمج، تقسيم، ضغط)، OCR (عربي/إنكليزي/ألماني) دون إنترنت،
استخراج بيانات الفواتير، توقيع وتعليقات وتظليل، قفل PIN، نسخ احتياطي، نسخة مجانية/Pro، واجهة بثلاث لغات.

## الإصدار 1.1
- خوارزمية قص جديدة: حواف Canny + مناطق مغلقة + تقطيع Otsu، مع تقييم بدعم الحواف وضبط الزوايا (تم اختبارها على مشاهد اصطناعية بدقات وضجيج مختلفة).
- وضع مسح افتراضي (فلتر/سطوع/تباين) من الإعدادات أو زر «تعيين كافتراضي» في شاشة التعديل.
- أدوات PDF: دمج، تقسيم بنطاقات متعددة، ضغط بثلاث درجات، استيراد للتعديل، وتحويل PDF إلى Word.
- حفظ الملفات في الهاتف أو مشاركتها. العلامة المائية الصغيرة: «Scanned with Loay Alhamra».
- اللغات: العربية / English / Deutsch.

## البناء
```bash
flutter create . --project-name mustanad --org com.mustanad
bash tool/ci_setup.sh
# حمّل بيانات OCR (ara, eng, deu) إلى assets/tessdata من
# https://github.com/tesseract-ocr/tessdata_fast  (build.yml يفعل ذلك تلقائياً)
flutter pub get
dart run flutter_launcher_icons
flutter build apk --release --no-shrink --target-platform android-arm,android-arm64
```

## البنية
```
lib/app/
  engine/        scanner_engine.dart  (محرك الصور: Isolate)
  core/          storage, pdf_service, ocr_service, invoice_parser, text_normalize, utils
  data/          db/app_db.dart + models/
  controllers/   app, docs, scan, tools
  views/         الشاشات + widgets/
  translations/  ar / de (الإنكليزية = نص المفاتيح)
```

## ملاحظات للنشر التجاري
- الدفع: `AppController.setPro` + `requirePro` جاهزان؛ اربطهما بـ `in_app_purchase` (معرّفات المنتجات من المتجر).
- السحابة: النسخ الاحتياطي ملف zip يُشارك إلى أي سحابة؛ للمزامنة التلقائية أضف مزوّد Google Drive/Firebase.
- حماية PDF بكلمة مرور على مستوى الملف غير مضمّنة؛ الحماية الحالية قفل PIN للتطبيق وللمستندات.
- iOS: يلزم Mac للبناء والتوقيع (يضيف `tool/ci_setup.sh` أذونات الكاميرا والصور إلى Info.plist).
