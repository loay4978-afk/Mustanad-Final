#!/usr/bin/env bash
# يُشغَّل بعد `flutter create .` لتهيئة أندرويد وiOS
set -e
MANIFEST=android/app/src/main/AndroidManifest.xml

# صلاحية الكاميرا
if ! grep -q "android.permission.CAMERA" "$MANIFEST"; then
  sed -i '0,/<application/s#<application#<uses-permission android:name="android.permission.CAMERA"/>\n    <uses-feature android:name="android.hardware.camera" android:required="false"/>\n    <application#' "$MANIFEST"
fi
# اسم التطبيق تحت الأيقونة
sed -i 's#android:label="[^"]*"#android:label="Mustanad"#' "$MANIFEST"

# أذونات iOS
if [ -f ios/Runner/Info.plist ]; then
python3 - <<'PY'
p='ios/Runner/Info.plist'
s=open(p,encoding='utf-8').read()
add=''
if 'NSCameraUsageDescription' not in s:
    add+='\t<key>NSCameraUsageDescription</key>\n\t<string>Camera is used to scan documents.</string>\n'
if 'NSPhotoLibraryUsageDescription' not in s:
    add+='\t<key>NSPhotoLibraryUsageDescription</key>\n\t<string>Photos are imported and converted to documents.</string>\n'
if add:
    i=s.rfind('</dict>')
    s=s[:i]+add+s[i:]
    open(p,'w',encoding='utf-8').write(s)
PY
fi

# رفع compileSdk لكل الإضافات إلى 36، وتعطيل lintVital (يفشل في بعض الإضافات)
if [ -f android/build.gradle.kts ] && ! grep -q MUSTANAD_COMPILE_SDK android/build.gradle.kts; then
  {
    cat <<'KTS'
// MUSTANAD_COMPILE_SDK
subprojects {
    afterEvaluate {
        if (project.name != "app") {
            extensions.findByType(com.android.build.api.dsl.CommonExtension::class.java)?.let { it.compileSdk = 36 }
        }
    }
}
subprojects {
    tasks.configureEach {
        if (name.startsWith("lintVital")) enabled = false
    }
}
KTS
    cat android/build.gradle.kts
  } > /tmp/root_build.kts
  cp /tmp/root_build.kts android/build.gradle.kts
elif [ -f android/build.gradle ] && ! grep -q MUSTANAD_COMPILE_SDK android/build.gradle; then
  {
    cat <<'GRV'
// MUSTANAD_COMPILE_SDK
subprojects {
    afterEvaluate { p ->
        if (p.name != 'app' && p.hasProperty('android')) {
            p.android { compileSdk 36 }
        }
    }
}
subprojects {
    tasks.configureEach { t ->
        if (t.name.startsWith('lintVital')) t.enabled = false
    }
}
GRV
    cat android/build.gradle
  } > /tmp/root_build.gradle
  cp /tmp/root_build.gradle android/build.gradle
fi
echo "ci_setup done"
