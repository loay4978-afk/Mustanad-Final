import 'dart:typed_data';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';

import '../core/pdf_service.dart';
import '../core/utils.dart';
import 'app_controller.dart';
import '../core/storage.dart';
import '../data/models/models.dart';
import '../engine/scanner_engine.dart';

/// جلسة المسح: مسودات الصفحات قبل الحفظ كمستند
class ScanController extends GetxController {
  final drafts = <PageEdit>[].obs;
  final pending = 0.obs; // عدد الصور قيد المعالجة
  int _uid = 0;
  int? targetDocId; // إذا كانت الجلسة لإضافة صفحات إلى مستند موجود
  bool _errShown = false;

  Future<void> addFile(String path, {bool detect = true, Uint8List? bytes, bool fullFrame = false, int? filter, bool neutral = false}) async {
    pending.value++;
    try {
      final out = await Storage.newPath('drafts', 'jpg');
      final r = await compute<Map<String, Object?>, Map<String, Object?>>(normalizeAndDetect, {
        'src': path,
        'bytes': bytes,
        'out': out,
        'detect': detect,
      });
      final app = Get.find<AppController>();
      final e = PageEdit(
        uid: ++_uid,
        origPath: out,
        origW: r['w'] as int,
        origH: r['h'] as int,
        corners: fullFrame ? [0, 0, 1, 0, 1, 1, 0, 1] : (r['corners'] as List).cast<double>(),
        filter: filter ?? app.defFilter.value,
        brightness: neutral ? 0 : app.defBrightness.value,
        contrast: neutral ? 1 : app.defContrast.value,
      );
      drafts.add(e);
      await rebuildThumb(e);
    } catch (e) {
      if (!_errShown) {
        _errShown = true;
        toast('Error'.tr, 'Import failed: @e'.trParams({'e': '$e'}), error: true);
      }
    } finally {
      pending.value--;
    }
  }

  Future<void> rebuildThumb(PageEdit e) async {
    e.busy = true;
    drafts.refresh();
    try {
      final r = await compute<Map<String, Object?>, Map<String, Object?>>(processEntry, {
        'path': e.origPath,
        'corners': e.corners,
        'filter': e.filter,
        'rotation': e.rotation,
        'brightness': e.brightness,
        'contrast': e.contrast,
        'maxSide': 480,
        'quality': 70,
      });
      final tp = await Storage.newPath('drafts', 'jpg');
      await File(tp).writeAsBytes(r['bytes'] as Uint8List);
      Storage.deleteQuiet(e.thumbPath);
      e.thumbPath = tp;
    } finally {
      e.busy = false;
      drafts.refresh();
    }
  }

  Future<void> addFiles(List<String> paths, {bool detect = true}) async {
    for (final p in paths) {
      await addFile(p, detect: detect);
    }
  }

  Future<int> pickFromGallery() async {
    final files = await ImagePicker().pickMultiImage();
    if (files.isEmpty) return 0;
    await addFiles(files.map((f) => f.path).toList());
    return files.length;
  }

  /// يحوّل صفحات PDF إلى مسودات (للاستيراد والدمج)
  Future<void> addPdf(String pdfPath) async {
    pending.value++;
    try {
      var n = 0;
      await for (final png in PdfService.rasterize(pdfPath)) {
        n++;
        await addFile('', bytes: png, detect: false, fullFrame: true, filter: 0, neutral: true);
      }
      if (n == 0) toast('Error'.tr, 'Could not read this PDF'.tr, error: true);
    } catch (e) {
      toast('Error'.tr, 'Import failed: @e'.trParams({'e': '$e'}), error: true);
    } finally {
      pending.value--;
    }
  }

  void remove(PageEdit e) {
    drafts.remove(e);
    Storage.deleteQuiet(e.thumbPath);
    Storage.deleteQuiet(e.origPath);
  }

  void reorder(int oldIndex, int newIndex) {
    if (newIndex > oldIndex) newIndex--;
    final e = drafts.removeAt(oldIndex);
    drafts.insert(newIndex, e);
  }

  Future<void> applyFilterToAll(int filter) async {
    for (final e in drafts) {
      e.filter = filter;
    }
    for (final e in drafts.toList()) {
      await rebuildThumb(e);
    }
  }

  void clear() {
    for (final e in drafts) {
      Storage.deleteQuiet(e.thumbPath);
      Storage.deleteQuiet(e.origPath);
    }
    drafts.clear();
    targetDocId = null;
    _errShown = false;
  }
}
