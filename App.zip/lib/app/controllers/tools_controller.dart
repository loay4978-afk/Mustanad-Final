import 'dart:io';

import 'package:archive/archive.dart';
import 'package:flutter/foundation.dart';
import 'package:get/get.dart';
import 'package:path/path.dart' as p;

import '../core/docx_service.dart';
import '../core/ocr_service.dart';
import '../core/pdf_service.dart';
import '../core/storage.dart';
import '../core/utils.dart';
import '../data/db/app_db.dart';
import '../data/models/models.dart';
import '../engine/scanner_engine.dart';
import 'app_controller.dart';
import 'docs_controller.dart';

Future<String> _zipEntry(Map<String, Object?> a) async {
  final dir = Directory(a['dir'] as String);
  final archive = Archive();
  for (final f in dir.listSync(recursive: true)) {
    if (f is! File) continue;
    final rel = p.relative(f.path, from: dir.path).replaceAll('\\', '/');
    if (rel.startsWith('drafts/') || rel.startsWith('tmp/')) continue;
    final bytes = f.readAsBytesSync();
    archive.addFile(ArchiveFile(rel, bytes.length, bytes));
  }
  final data = ZipEncoder().encode(archive)!;
  File(a['out'] as String).writeAsBytesSync(data);
  return a['out'] as String;
}

Future<int> _unzipEntry(Map<String, Object?> a) async {
  final bytes = File(a['zip'] as String).readAsBytesSync();
  final archive = ZipDecoder().decodeBytes(bytes);
  final root = a['dir'] as String;
  var n = 0;
  for (final f in archive) {
    if (!f.isFile) continue;
    if (f.name.contains('..')) continue; // حماية من مسارات خبيثة
    final out = File(p.join(root, f.name));
    out.parent.createSync(recursive: true);
    out.writeAsBytesSync(f.content as List<int>);
    n++;
  }
  return n;
}

class ToolsController extends GetxController {
  bool get _free => !Get.find<AppController>().isPro.value;

  /// يحوّل PDF خارجي إلى ملفات JPG مؤقتة: مسارات + أبعاد (w,h,w,h...)
  Future<({List<String> paths, List<int> dims})> rasterizeToTemp(String pdfPath, {double dpi = 150, RxInt? progress}) async {
    final paths = <String>[];
    final dims = <int>[];
    await for (final png in PdfService.rasterize(pdfPath, dpi: dpi)) {
      final out = await Storage.newPath('tmp', 'jpg');
      final r = await compute<Map<String, Object?>, Map<String, Object?>>(normalizeAndDetect, {
        'bytes': png,
        'out': out,
        'detect': false,
      });
      paths.add(out);
      dims.addAll([r['w'] as int, r['h'] as int]);
      if (progress != null) progress.value = progress.value + 1;
    }
    if (paths.isEmpty) throw Exception('Could not read this PDF'.tr);
    return (paths: paths, dims: dims);
  }

  void _cleanup(Iterable<String> paths) {
    for (final x in paths) {
      Storage.deleteQuiet(x);
    }
  }

  // ───────── دمج ملفات PDF ─────────
  Future<File> mergePdfs(List<String> pdfPaths, String title, {RxInt? progress}) async {
    final all = <String>[];
    final dims = <int>[];
    try {
      for (final path in pdfPaths) {
        final r = await rasterizeToTemp(path, dpi: 170, progress: progress);
        all.addAll(r.paths);
        dims.addAll(r.dims);
      }
      return await PdfService.build(title, all, dims, PdfOptions(quality: 0, size: 'fit', watermark: _free));
    } finally {
      _cleanup(all);
    }
  }

  // ───────── تقسيم ملف PDF ─────────
  /// groups: قائمة نطاقات (أرقام صفحات تبدأ من 1). ترجع الملفات الناتجة.
  Future<List<File>> splitPdf(String pdfPath, String baseTitle, String ranges, bool eachPage, {RxInt? progress}) async {
    final r = await rasterizeToTemp(pdfPath, dpi: 150, progress: progress);
    try {
      final n = r.paths.length;
      final groups = <List<int>>[];
      final labels = <String>[];
      if (eachPage) {
        for (var i = 1; i <= n; i++) {
          groups.add([i]);
          labels.add('p$i');
        }
      } else {
        for (final part in ranges.split(RegExp(r'[;\n|]'))) {
          final g = parseRanges(part, n);
          if (g.isNotEmpty) {
            groups.add(g);
            labels.add(g.length == 1 ? 'p${g.first}' : '${g.first}-${g.last}');
          }
        }
      }
      if (groups.isEmpty) return [];
      final out = <File>[];
      for (var i = 0; i < groups.length; i++) {
        final g = groups[i];
        out.add(await PdfService.build(
          '${baseTitle}_${labels[i]}',
          [for (final pg in g) r.paths[pg - 1]],
          [for (final pg in g) ...[r.dims[2 * (pg - 1)], r.dims[2 * (pg - 1) + 1]]],
          PdfOptions(quality: 0, size: 'fit', watermark: _free),
        ));
      }
      return out;
    } finally {
      _cleanup(r.paths);
    }
  }

  // ───────── ضغط ملف PDF ─────────
  Future<File> compressPdf(String pdfPath, String title, int quality, {RxInt? progress}) async {
    final dpi = quality == 1 ? 130.0 : (quality == 2 ? 100.0 : 80.0);
    final r = await rasterizeToTemp(pdfPath, dpi: dpi, progress: progress);
    try {
      return await PdfService.build(title, r.paths, r.dims, PdfOptions(quality: quality, size: 'fit', watermark: _free));
    } finally {
      _cleanup(r.paths);
    }
  }

  // ───────── PDF → Word ─────────
  Future<File> _imagesToWord(String title, List<String> paths, List<int> dims, List<double> dpis, String mode, List<String> langs, RxInt? progress) async {
    final pages = <WordPageInput>[];
    for (var i = 0; i < paths.length; i++) {
      Uint8List? img;
      String? hocr, plain;
      if (mode == 'exact') {
        img = await File(paths[i]).readAsBytes();
      } else {
        try {
          hocr = await OcrService.recognizeHocr(paths[i], langs);
        } catch (_) {
          hocr = null;
        }
        if (hocr == null || !hocr.contains('ocr_')) {
          hocr = null;
          try {
            plain = await OcrService.recognize(paths[i], langs);
          } catch (_) {}
        }
      }
      pages.add(WordPageInput(imgW: dims[2 * i], imgH: dims[2 * i + 1], dpi: dpis[i], hocr: hocr, plain: plain, image: img));
      progress?.value = i + 1;
    }
    final bytes = await DocxService.build(pages, mode);
    final f = await Storage.tempFile('${PdfService.safeName(title)}.docx');
    await f.writeAsBytes(bytes, flush: true);
    return f;
  }

  Future<File> pdfFileToWord(String pdfPath, String title, String mode, List<String> langs, {RxInt? progress}) async {
    final r = await rasterizeToTemp(pdfPath, dpi: 150);
    try {
      return await _imagesToWord(title, r.paths, r.dims, List.filled(r.paths.length, 150.0), mode, langs, progress);
    } finally {
      _cleanup(r.paths);
    }
  }

  Future<File> docToWord(DocModel d, List<PageModel> pages, String mode, List<String> langs, {RxInt? progress}) {
    final dims = <int>[];
    final dpis = <double>[];
    for (final pg in pages) {
      dims.addAll([pg.width, pg.height]);
      // الصفحات الممسوحة تُعدّ بحجم A4 تقريباً
      dpis.add(pg.width / (pg.width > pg.height ? 11.69 : 8.27));
    }
    return _imagesToWord(d.title, pages.map((x) => x.displayPath).toList(), dims, dpis, mode, langs, progress);
  }

  // ───────── النسخ الاحتياطي ─────────
  Future<File> backup() async {
    final base = await Storage.base();
    final stamp = DateTime.now().toIso8601String().substring(0, 19).replaceAll(RegExp(r'[:T]'), '-');
    final out = await Storage.tempFile('mustanad_backup_$stamp.zip');
    await compute<Map<String, Object?>, String>(_zipEntry, {'dir': base.path, 'out': out.path});
    return out;
  }

  Future<int> restore(String zipPath) async {
    final base = await Storage.base();
    await AppDb.instance.close();
    for (final e in base.listSync()) {
      try {
        e.deleteSync(recursive: true);
      } catch (_) {}
    }
    final n = await compute<Map<String, Object?>, int>(_unzipEntry, {'zip': zipPath, 'dir': base.path});
    await Get.find<AppController>().load();
    await Get.find<DocsController>().load();
    return n;
  }
}
