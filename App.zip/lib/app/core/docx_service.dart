// تحويل صفحات (صور) إلى ملف Word (.docx):
//  - وضع "قابل للتعديل": إعادة بناء الفقرات من نتيجة hOCR (الاتجاه، المحاذاة، حجم الخط، الخط العريض، المسافات، الهوامش)
//  - وضع "نسخة طبق الأصل": كل صفحة كصورة بحجم الصفحة كاملة
import 'dart:convert';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:archive/archive.dart';
import 'package:flutter/foundation.dart';

class WordPageInput {
  final int imgW, imgH;
  final double dpi;
  final String? hocr;
  final String? plain;
  final Uint8List? image; // لوضع النسخة الأصلية
  const WordPageInput({required this.imgW, required this.imgH, required this.dpi, this.hocr, this.plain, this.image});
}

class _HLine {
  double x0 = 0, y0 = 0, x1 = 0, y1 = 0;
  String text = '';
  int words = 0, bold = 0, ital = 0;
  bool header = false;
}

class _HPar {
  final List<_HLine> lines = [];
  double get x0 => lines.map((l) => l.x0).reduce(math.min);
  double get y0 => lines.map((l) => l.y0).reduce(math.min);
  double get x1 => lines.map((l) => l.x1).reduce(math.max);
  double get y1 => lines.map((l) => l.y1).reduce(math.max);
}

final _bboxRe = RegExp(r'bbox\s+(-?\d+)\s+(-?\d+)\s+(-?\d+)\s+(-?\d+)');
final _parRe = RegExp(r'''<p\b[^>]*class=['"]ocr_par['"][^>]*>''');
final _lineRe = RegExp(r'''<span\b[^>]*class=['"]ocr_(?:line|header|textfloat|caption)['"][^>]*>''');
final _wordRe = RegExp(r'''(<span\b[^>]*class=['"]ocrx_word['"][^>]*>)(.*?)</span>''', dotAll: true);
final _tagRe = RegExp(r'<[^>]*>');

String _unescape(String s) {
  return s
      .replaceAllMapped(RegExp(r'&#x([0-9a-fA-F]+);'), (m) => String.fromCharCode(int.parse(m.group(1)!, radix: 16)))
      .replaceAllMapped(RegExp(r'&#(\d+);'), (m) => String.fromCharCode(int.parse(m.group(1)!)))
      .replaceAll('&lt;', '<')
      .replaceAll('&gt;', '>')
      .replaceAll('&quot;', '"')
      .replaceAll('&apos;', "'")
      .replaceAll('&amp;', '&');
}

List<_HPar> _parseHocr(String h) {
  final pars = <_HPar>[];
  var starts = _parRe.allMatches(h).map((m) => m.start).toList();
  if (starts.isEmpty) starts = [0];
  for (var i = 0; i < starts.length; i++) {
    final seg = h.substring(starts[i], i + 1 < starts.length ? starts[i + 1] : h.length);
    final lm = _lineRe.allMatches(seg).toList();
    final par = _HPar();
    for (var j = 0; j < lm.length; j++) {
      final tag = lm[j].group(0)!;
      final body = seg.substring(lm[j].end, j + 1 < lm.length ? lm[j + 1].start : seg.length);
      final bb = _bboxRe.firstMatch(tag);
      if (bb == null) continue;
      final line = _HLine()
        ..x0 = double.parse(bb.group(1)!)
        ..y0 = double.parse(bb.group(2)!)
        ..x1 = double.parse(bb.group(3)!)
        ..y1 = double.parse(bb.group(4)!)
        ..header = tag.contains('ocr_header');
      final words = <String>[];
      for (final wm in _wordRe.allMatches(body)) {
        final inner = wm.group(2)!;
        final t = _unescape(inner.replaceAll(_tagRe, '')).trim();
        if (t.isEmpty) continue;
        words.add(t);
        if (inner.contains('<strong>')) line.bold++;
        if (inner.contains('<em>')) line.ital++;
      }
      if (words.isEmpty) continue;
      line.words = words.length;
      line.text = words.join(' ');
      par.lines.add(line);
    }
    if (par.lines.isNotEmpty) pars.add(par);
  }
  return pars;
}

bool _isRtl(String s) {
  var ar = 0, la = 0;
  for (final r in s.runes) {
    if ((r >= 0x0590 && r <= 0x08FF) || (r >= 0xFB1D && r <= 0xFEFC)) {
      ar++;
    } else if ((r >= 0x41 && r <= 0x5A) || (r >= 0x61 && r <= 0x7A)) {
      la++;
    }
  }
  return ar > 0 && ar >= la;
}

double _median(List<double> v) {
  if (v.isEmpty) return 0;
  final s = List<double>.of(v)..sort();
  return s[s.length ~/ 2];
}

String _joinLines(_HPar p) {
  final w = p.x1 - p.x0;
  final b = StringBuffer();
  for (var i = 0; i < p.lines.length; i++) {
    final l = p.lines[i];
    b.write(l.text);
    if (i < p.lines.length - 1) {
      final short = (l.x1 - l.x0) < 0.6 * w;
      b.write(short ? '\n' : ' ');
    }
  }
  return b.toString();
}

/// يحوّل hOCR لصفحة واحدة إلى فقرات جاهزة (خرائط بسيطة) + هوامش مقترحة
Map<String, Object?> _layoutPage(List<_HPar> pars, int imgW, int imgH, double dpi, double body, int wTw, int hTw) {
  final twPerPx = wTw / imgW;
  if (pars.isEmpty) return {'paras': <Map<String, Object?>>[], 'ml': 1134, 'mr': 1134, 'mt': 1134, 'mb': 1134};
  final left = pars.map((p) => p.x0).reduce(math.min), right = pars.map((p) => p.x1).reduce(math.max);
  final top = pars.map((p) => p.y0).reduce(math.min), bottom = pars.map((p) => p.y1).reduce(math.max);
  final textW = math.max(1.0, right - left);
  final out = <Map<String, Object?>>[];
  for (var i = 0; i < pars.length; i++) {
    final p = pars[i];
    final text = _joinLines(p);
    final rtl = _isRtl(text);
    final pw = p.x1 - p.x0;
    final leftSlack = p.x0 - left, rightSlack = right - p.x1;
    final nLines = p.lines.length;

    // المحاذاة الفيزيائية
    String phys;
    if (leftSlack < 0.03 * textW && rightSlack < 0.03 * textW) {
      phys = rtl ? 'r' : 'l';
      if (nLines >= 3) {
        final edges = [for (final l in p.lines.take(nLines - 1)) rtl ? l.x0 : l.x1];
        final mean = edges.reduce((a, b) => a + b) / edges.length;
        final sd = math.sqrt(edges.map((e) => (e - mean) * (e - mean)).reduce((a, b) => a + b) / edges.length);
        if (sd < 0.008 * imgW) phys = 'j';
      }
    } else if ((leftSlack - rightSlack).abs() < 0.06 * imgW && leftSlack > 0.04 * imgW) {
      phys = 'c';
    } else {
      phys = leftSlack < rightSlack ? 'l' : 'r';
    }
    String jc;
    if (phys == 'c') {
      jc = 'center';
    } else if (phys == 'j') {
      jc = 'both';
    } else if (rtl) {
      jc = phys == 'r' ? '' : 'right';
    } else {
      jc = phys == 'l' ? '' : 'right';
    }

    // حجم الخط
    final lineH = _median([for (final l in p.lines) l.y1 - l.y0]);
    var sz = lineH * 72 / dpi / 0.95;
    if (body > 0 && (sz - body).abs() / body <= 0.15) {
      sz = body;
    } else {
      sz = (sz * 2).round() / 2;
    }
    sz = sz.clamp(6.0, 48.0);
    final boldWords = p.lines.fold<int>(0, (a, l) => a + l.bold), allWords = p.lines.fold<int>(0, (a, l) => a + l.words);
    final italWords = p.lines.fold<int>(0, (a, l) => a + l.ital);
    final headerLike = p.lines.any((l) => l.header) || (body > 0 && sz >= body * 1.25 && nLines <= 2 && text.length <= 120);
    final bold = headerLike || (allWords > 0 && boldWords / allWords >= 0.6);
    final ital = allWords > 0 && italWords / allWords >= 0.6;

    // مسافات
    final szPx = sz * dpi / 72;
    final pitch = (p.y1 - p.y0) / nLines;
    final line = (240 * pitch / (szPx * 1.15)).clamp(240.0, 600.0).round();
    var after = 80;
    if (i + 1 < pars.length) {
      final gapPt = (pars[i + 1].y0 - p.y1) / dpi * 72;
      after = (gapPt * 20).clamp(40.0, 900.0).round();
    } else {
      after = 0;
    }
    var indL = 0, indR = 0, first = 0;
    if (!rtl && phys == 'l') indL = (leftSlack * twPerPx).clamp(0.0, 6000.0).round();
    if (!rtl && phys == 'r') indR = (rightSlack * twPerPx).clamp(0.0, 6000.0).round();
    if (!rtl && nLines >= 2) {
      final minRest = p.lines.skip(1).map((l) => l.x0).reduce(math.min);
      final d = p.lines.first.x0 - minRest;
      if (d > 0.015 * imgW) first = (d * twPerPx).clamp(0.0, 1200.0).round();
    }
    out.add({
      't': text,
      'rtl': rtl,
      'jc': jc,
      'sz': (sz * 2).round(),
      'b': bold,
      'i': ital,
      'after': after,
      'line': line,
      'indL': indL,
      'indR': indR,
      'first': first,
    });
  }
  int clampM(double v) => v.clamp(283.0, 3400.0).round();
  return {
    'paras': out,
    'ml': clampM(left / imgW * wTw),
    'mr': clampM((imgW - right) / imgW * wTw),
    'mt': clampM(top / imgH * hTw),
    'mb': clampM((imgH - bottom) / imgH * hTw),
  };
}

/// بديل عند غياب hOCR: فقرات من النص العادي
List<Map<String, Object?>> _plainParas(String text) {
  final out = <Map<String, Object?>>[];
  for (final block in text.split(RegExp(r'\n\s*\n'))) {
    final t = block.trim();
    if (t.isEmpty) continue;
    out.add({'t': t, 'rtl': _isRtl(t), 'jc': '', 'sz': 22, 'b': false, 'i': false, 'after': 160, 'line': 276, 'indL': 0, 'indR': 0, 'first': 0});
  }
  return out;
}

String _esc(String s) {
  final b = StringBuffer();
  for (final r in s.runes) {
    final ok = r == 0x9 || r == 0xA || r == 0xD || (r >= 0x20 && r <= 0xD7FF) || (r >= 0xE000 && r <= 0xFFFD) || (r >= 0x10000 && r <= 0x10FFFF);
    if (!ok) continue;
    switch (r) {
      case 0x26:
        b.write('&amp;');
        break;
      case 0x3C:
        b.write('&lt;');
        break;
      case 0x3E:
        b.write('&gt;');
        break;
      case 0x22:
        b.write('&quot;');
        break;
      default:
        b.writeCharCode(r);
    }
  }
  return b.toString();
}

String _paraXml(Map p, {bool pageBreak = false}) {
  final rtl = p['rtl'] == true;
  final b = StringBuffer('<w:p><w:pPr>');
  if (pageBreak) b.write('<w:pageBreakBefore/>');
  if (rtl) b.write('<w:bidi/>');
  b.write('<w:spacing w:before="0" w:after="${p['after']}" w:line="${p['line']}" w:lineRule="auto"/>');
  final indL = p['indL'] as int, indR = p['indR'] as int, first = p['first'] as int;
  if (indL > 0 || indR > 0 || first > 0) {
    b.write('<w:ind w:left="$indL" w:right="$indR"${first > 0 ? ' w:firstLine="$first"' : ''}/>');
  }
  final jc = p['jc'] as String;
  if (jc.isNotEmpty) b.write('<w:jc w:val="$jc"/>');
  b.write('</w:pPr>');
  final parts = (p['t'] as String).split('\n');
  for (var i = 0; i < parts.length; i++) {
    b.write('<w:r><w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial" w:cs="Arial" w:eastAsia="Arial"/>');
    if (p['b'] == true) b.write('<w:b/><w:bCs/>');
    if (p['i'] == true) b.write('<w:i/><w:iCs/>');
    b.write('<w:sz w:val="${p['sz']}"/><w:szCs w:val="${p['sz']}"/>');
    if (rtl) b.write('<w:rtl/>');
    b.write('</w:rPr>');
    if (i > 0) b.write('<w:br/>');
    b.write('<w:t xml:space="preserve">${_esc(parts[i])}</w:t></w:r>');
  }
  b.write('</w:p>');
  return b.toString();
}

String _imageParaXml(int idx, int cx, int cy, bool pageBreak) {
  return '<w:p><w:pPr>${pageBreak ? '<w:pageBreakBefore/>' : ''}<w:spacing w:before="0" w:after="0" w:line="240" w:lineRule="auto"/><w:jc w:val="center"/></w:pPr>'
      '<w:r><w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0"><wp:extent cx="$cx" cy="$cy"/>'
      '<wp:docPr id="$idx" name="Page $idx"/><a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture">'
      '<pic:pic><pic:nvPicPr><pic:cNvPr id="$idx" name="page$idx.jpg"/><pic:cNvPicPr/></pic:nvPicPr>'
      '<pic:blipFill><a:blip r:embed="rImg$idx"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>'
      '<pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="$cx" cy="$cy"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr>'
      '</pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p>';
}

const _ns =
    'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" '
    'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" '
    'xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" '
    'xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" '
    'xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture"';

/// تجميع الحزمة (zip) — يعمل داخل Isolate
Uint8List _zipDocx(Map<String, Object?> a) {
  final bodyXml = a['body'] as String;
  final sect = a['sect'] as String;
  final images = (a['images'] as List).cast<Uint8List>();
  final ar = Archive();
  void add(String name, List<int> data) => ar.addFile(ArchiveFile(name, data.length, data));
  const head = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n';
  add('[Content_Types].xml', utf8.encode('$head<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
      '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
      '<Default Extension="xml" ContentType="application/xml"/>'
      '<Default Extension="jpg" ContentType="image/jpeg"/>'
      '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>'
      '<Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>'
      '</Types>'));
  add('_rels/.rels', utf8.encode('$head<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
      '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>'
      '</Relationships>'));
  final rels = StringBuffer('$head<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
      '<Relationship Id="rIdStyles" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>');
  for (var i = 0; i < images.length; i++) {
    rels.write('<Relationship Id="rImg${i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/page${i + 1}.jpg"/>');
  }
  rels.write('</Relationships>');
  add('word/_rels/document.xml.rels', utf8.encode(rels.toString()));
  add('word/styles.xml', utf8.encode('$head<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
      '<w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial" w:cs="Arial" w:eastAsia="Arial"/>'
      '<w:sz w:val="22"/><w:szCs w:val="22"/><w:lang w:val="en-US" w:eastAsia="en-US" w:bidi="ar-SA"/></w:rPr></w:rPrDefault>'
      '<w:pPrDefault><w:pPr><w:spacing w:after="120" w:line="259" w:lineRule="auto"/></w:pPr></w:pPrDefault></w:docDefaults>'
      '<w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/></w:style></w:styles>'));
  add('word/document.xml', utf8.encode('$head<w:document $_ns><w:body>$bodyXml$sect</w:body></w:document>'));
  for (var i = 0; i < images.length; i++) {
    add('word/media/page${i + 1}.jpg', images[i]);
  }
  return Uint8List.fromList(ZipEncoder().encode(ar)!);
}

class DocxService {
  DocxService._();

  /// mode: 'editable' | 'exact'
  static Future<Uint8List> build(List<WordPageInput> pages, String mode) async {
    if (pages.isEmpty) throw Exception('no pages');
    final first = pages.first;
    final wTw = (first.imgW / first.dpi * 1440).round(), hTw = (first.imgH / first.dpi * 1440).round();
    final body = StringBuffer();
    final images = <Uint8List>[];
    String sect;

    if (mode == 'exact') {
      for (var i = 0; i < pages.length; i++) {
        final p = pages[i];
        final pw = (p.imgW / p.dpi * 1440).round(), ph = (p.imgH / p.dpi * 1440).round();
        final f = (ph - 80) / ph; // أصغر قليلاً كي لا تنتقل الصورة لصفحة جديدة
        body.write(_imageParaXml(i + 1, (pw * f * 635).round(), ((ph - 80) * 635).round(), i > 0));
        images.add(p.image!);
      }
      sect = '<w:sectPr><w:pgSz w:w="$wTw" w:h="$hTw"/><w:pgMar w:top="0" w:right="0" w:bottom="0" w:left="0" w:header="0" w:footer="0" w:gutter="0"/></w:sectPr>';
    } else {
      // حجم الخط الأساسي = الوسيط المرجّح بعدد الأحرف
      final parsed = <List<_HPar>?>[];
      final sizes = <List<double>>[];
      for (final p in pages) {
        List<_HPar>? pars;
        if (p.hocr != null) {
          try {
            pars = _parseHocr(p.hocr!);
          } catch (_) {
            pars = null;
          }
        }
        parsed.add(pars);
        if (pars != null) {
          for (final par in pars) {
            final lh = _median([for (final l in par.lines) l.y1 - l.y0]);
            final len = _joinLines(par).length;
            sizes.add([lh * 72 / p.dpi / 0.95, len.toDouble()]);
          }
        }
      }
      var bodySz = 0.0;
      if (sizes.isNotEmpty) {
        sizes.sort((a, b) => a[0].compareTo(b[0]));
        final totalLen = sizes.fold<double>(0, (a, s) => a + s[1]);
        var acc = 0.0;
        for (final s in sizes) {
          acc += s[1];
          if (acc >= totalLen / 2) {
            bodySz = (s[0] * 2).round() / 2;
            break;
          }
        }
      }
      var ml = 1134, mr = 1134, mt = 1134, mb = 1134;
      var haveMargins = false;
      for (var i = 0; i < pages.length; i++) {
        final p = pages[i];
        final pw = (p.imgW / p.dpi * 1440).round(), ph = (p.imgH / p.dpi * 1440).round();
        List<Map<String, Object?>> paras;
        if (parsed[i] != null && parsed[i]!.isNotEmpty) {
          final lay = _layoutPage(parsed[i]!, p.imgW, p.imgH, p.dpi, bodySz, pw, ph);
          paras = (lay['paras'] as List).cast<Map<String, Object?>>();
          if (!haveMargins) {
            ml = lay['ml'] as int;
            mr = lay['mr'] as int;
            mt = lay['mt'] as int;
            mb = lay['mb'] as int;
            haveMargins = true;
          }
        } else {
          paras = _plainParas(p.plain ?? '');
        }
        if (paras.isEmpty) {
          body.write('<w:p><w:pPr>${i > 0 ? '<w:pageBreakBefore/>' : ''}</w:pPr></w:p>');
        } else {
          for (var k = 0; k < paras.length; k++) {
            body.write(_paraXml(paras[k], pageBreak: i > 0 && k == 0));
          }
        }
      }
      sect = '<w:sectPr><w:pgSz w:w="$wTw" w:h="$hTw"/><w:pgMar w:top="$mt" w:right="$mr" w:bottom="$mb" w:left="$ml" w:header="0" w:footer="0" w:gutter="0"/></w:sectPr>';
    }
    return compute<Map<String, Object?>, Uint8List>(_zipDocx, {'body': body.toString(), 'sect': sect, 'images': images});
  }
}
