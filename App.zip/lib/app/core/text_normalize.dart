/// توحيد النص للبحث الذكي: يتجاهل التشكيل والهمزات والتاء المربوطة والحروف المعلّمة
const Map<String, String> _map = {
  'أ': 'ا', 'إ': 'ا', 'آ': 'ا', 'ٱ': 'ا', 'ى': 'ي', 'ئ': 'ي', 'ة': 'ه', 'ؤ': 'و',
  'ä': 'a', 'ö': 'o', 'ü': 'u', 'ß': 'ss',
  'é': 'e', 'è': 'e', 'ê': 'e', 'ë': 'e', 'á': 'a', 'à': 'a', 'â': 'a', 'ã': 'a', 'å': 'a',
  'í': 'i', 'ì': 'i', 'î': 'i', 'ï': 'i', 'ó': 'o', 'ò': 'o', 'ô': 'o', 'õ': 'o',
  'ú': 'u', 'ù': 'u', 'û': 'u', 'ç': 'c', 'ñ': 'n',
};

String normalizeText(String input) {
  final s = input.toLowerCase();
  final b = StringBuffer();
  for (var i = 0; i < s.length; i++) {
    final ch = s[i];
    final u = ch.codeUnitAt(0);
    if ((u >= 0x064B && u <= 0x065F) || u == 0x0670 || u == 0x0640) continue; // تشكيل + تطويل
    if (u >= 0x0660 && u <= 0x0669) {
      b.write(u - 0x0660);
      continue;
    }
    if (u >= 0x06F0 && u <= 0x06F9) {
      b.write(u - 0x06F0);
      continue;
    }
    b.write(_map[ch] ?? ch);
  }
  return b.toString();
}

/// هل تحتوي النصوص كل كلمات البحث؟
bool matchesAll(String haystackNormalized, String query) {
  final terms = normalizeText(query).split(RegExp(r'\s+')).where((t) => t.isNotEmpty);
  for (final t in terms) {
    if (!haystackNormalized.contains(t)) return false;
  }
  return true;
}

/// مقتطف حول أول كلمة مطابقة
String snippetAround(String text, String query, {int radius = 40}) {
  final norm = normalizeText(text);
  final terms = normalizeText(query).split(RegExp(r'\s+')).where((t) => t.isNotEmpty).toList();
  if (terms.isEmpty) return '';
  var idx = -1;
  for (final t in terms) {
    idx = norm.indexOf(t);
    if (idx >= 0) break;
  }
  if (idx < 0) return '';
  final start = (idx - radius).clamp(0, text.length);
  final end = (idx + radius).clamp(0, text.length);
  final s = text.substring(start, end).replaceAll(RegExp(r'\s+'), ' ').trim();
  return '${start > 0 ? '…' : ''}$s${end < text.length ? '…' : ''}';
}
