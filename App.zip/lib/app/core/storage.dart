import 'dart:io';

import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

/// كل الملفات داخل مجلد التطبيق الخاص (خصوصية: لا تظهر في المعرض)
class Storage {
  Storage._();
  static Directory? _base;
  static int _n = 0;

  static Future<Directory> base() async {
    if (_base == null) {
      final d = await getApplicationDocumentsDirectory();
      _base = Directory(p.join(d.path, 'mustanad'));
    }
    if (!_base!.existsSync()) _base!.createSync(recursive: true);
    return _base!;
  }

  static Future<Directory> sub(String name) async {
    final d = Directory(p.join((await base()).path, name));
    if (!d.existsSync()) d.createSync(recursive: true);
    return d;
  }

  static Future<String> newPath(String subDir, String ext) async {
    final d = await sub(subDir);
    _n++;
    return p.join(d.path, '${DateTime.now().microsecondsSinceEpoch}_$_n.$ext');
  }

  static Future<String> dbPath() async => p.join((await base()).path, 'mustanad.db');

  static Future<File> tempFile(String name) async {
    final d = await getTemporaryDirectory();
    return File(p.join(d.path, name));
  }

  static void deleteQuiet(String? path) {
    if (path == null) return;
    try {
      final f = File(path);
      if (f.existsSync()) f.deleteSync();
    } catch (_) {}
  }
}
