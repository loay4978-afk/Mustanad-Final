import 'package:flutter_tesseract_ocr/flutter_tesseract_ocr.dart';

/// OCR دون إنترنت عبر Tesseract (العربية + الإنكليزية + الألمانية)
class OcrService {
  OcrService._();

  static const Map<String, String> languages = {
    'ara': 'العربية / Arabic',
    'eng': 'English',
    'deu': 'Deutsch',
  };

  static Future<String> recognize(String imagePath, List<String> langs) async {
    final lang = langs.isEmpty ? 'eng' : langs.join('+');
    final text = await FlutterTesseractOcr.extractText(
      imagePath,
      language: lang,
      args: {'psm': '3', 'preserve_interword_spaces': '1'},
    );
    return text.replaceAll('\r', '').replaceAll(RegExp(r'\n{3,}'), '\n\n').trim();
  }

  /// نتيجة hOCR (مواضع الكلمات والأسطر والفقرات) لإعادة بناء التنسيق في Word
  static Future<String> recognizeHocr(String imagePath, List<String> langs) async {
    final lang = langs.isEmpty ? 'eng' : langs.join('+');
    return FlutterTesseractOcr.extractHocr(
      imagePath,
      language: lang,
      args: {'psm': '3', 'preserve_interword_spaces': '1'},
    );
  }
}
