import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart' show DateFormat;

String get lc => Get.locale?.languageCode ?? 'ar';

String fmtDate(DateTime d) => DateFormat('d MMM yyyy • HH:mm', lc).format(d);

String fmtBytes(int b) {
  if (b < 1024) return '$b B';
  if (b < 1024 * 1024) return '${(b / 1024).toStringAsFixed(0)} KB';
  return '${(b / 1024 / 1024).toStringAsFixed(1)} MB';
}

void toast(String title, String msg, {bool error = false}) {
  Get.snackbar(
    title,
    msg,
    snackPosition: SnackPosition.BOTTOM,
    margin: const EdgeInsets.all(12),
    backgroundColor: error ? Colors.red.shade700 : Colors.teal.shade700,
    colorText: Colors.white,
  );
}

Future<bool> confirm(String title, String msg) async {
  final r = await Get.dialog<bool>(AlertDialog(
    title: Text(title),
    content: Text(msg),
    actions: [
      TextButton(onPressed: () => Get.back(result: false), child: Text('Cancel'.tr)),
      FilledButton(onPressed: () => Get.back(result: true), child: Text('Confirm'.tr)),
    ],
  ));
  return r ?? false;
}

Future<String?> askText(String title, {String initial = '', String? hint, bool obscure = false, TextInputType? keyboard}) async {
  final ctrl = TextEditingController(text: initial);
  final r = await Get.dialog<String>(AlertDialog(
    title: Text(title),
    content: TextField(
      controller: ctrl,
      autofocus: true,
      obscureText: obscure,
      keyboardType: keyboard,
      decoration: InputDecoration(hintText: hint),
      onSubmitted: (v) => Get.back(result: v),
    ),
    actions: [
      TextButton(onPressed: () => Get.back(), child: Text('Cancel'.tr)),
      FilledButton(onPressed: () => Get.back(result: ctrl.text), child: Text('OK'.tr)),
    ],
  ));
  return r;
}

/// يحلل "1-3,5" إلى قائمة أرقام صفحات (تبدأ من 1)
List<int> parseRanges(String s, int max) {
  final out = <int>[];
  for (final part in s.split(RegExp(r'[,،;\s]+'))) {
    if (part.isEmpty) continue;
    final m = RegExp(r'^(\d+)\s*-\s*(\d+)$').firstMatch(part);
    if (m != null) {
      var a = int.parse(m.group(1)!), b = int.parse(m.group(2)!);
      if (a > b) {
        final t = a;
        a = b;
        b = t;
      }
      for (var i = a; i <= b; i++) {
        if (i >= 1 && i <= max && !out.contains(i)) out.add(i);
      }
    } else {
      final n = int.tryParse(part);
      if (n != null && n >= 1 && n <= max && !out.contains(n)) out.add(n);
    }
  }
  return out;
}
