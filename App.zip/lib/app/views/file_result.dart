import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:path/path.dart' as p;
import 'package:share_plus/share_plus.dart';

import '../core/utils.dart';

/// حفظ الملفات في الهاتف (يفتح مدير الملفات لاختيار المكان)
Future<void> saveToPhone(List<File> files) async {
  for (final f in files) {
    final name = p.basename(f.path);
    final ext = p.extension(name).replaceFirst('.', '').toLowerCase();
    try {
      final bytes = await f.readAsBytes();
      final path = await FilePicker.platform.saveFile(
        dialogTitle: 'Save to phone'.tr,
        fileName: name,
        type: FileType.custom,
        allowedExtensions: [ext],
        bytes: bytes,
      );
      if (path == null) {
        toast('Save'.tr, 'Save cancelled'.tr);
        return;
      }
      toast('Save'.tr, 'Saved to: @p'.trParams({'p': path}));
    } catch (e) {
      toast('Error'.tr, 'Could not save the file'.tr, error: true);
      return;
    }
  }
}

Future<void> shareFiles(List<File> files, {String? text}) async {
  await Share.shareXFiles([for (final f in files) XFile(f.path)], text: text);
}

/// نافذة نتيجة: حفظ في الهاتف أو مشاركة
Future<void> showFileResult(List<File> files, {String? note, String? shareText}) async {
  await Get.dialog(AlertDialog(
    title: Row(children: [
      const Icon(Icons.check_circle, color: Colors.green),
      const SizedBox(width: 8),
      Expanded(child: Text(files.length == 1 ? 'Your file is ready'.tr : 'Files ready: @n'.trParams({'n': '${files.length}'}))),
    ]),
    content: SingleChildScrollView(
      child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        for (final f in files)
          ListTile(
            dense: true,
            contentPadding: EdgeInsets.zero,
            leading: Icon(p.extension(f.path).toLowerCase() == '.docx' ? Icons.description : Icons.picture_as_pdf, color: Colors.blueGrey),
            title: Text(p.basename(f.path), maxLines: 2, overflow: TextOverflow.ellipsis),
            subtitle: Text(fmtBytes(f.lengthSync())),
          ),
        if (note != null) ...[const SizedBox(height: 8), Text(note, style: Theme.of(Get.context!).textTheme.bodySmall)],
      ]),
    ),
    actions: [
      TextButton(onPressed: () => Get.back(), child: Text('Close'.tr)),
      OutlinedButton.icon(
        icon: const Icon(Icons.save_alt),
        label: Text('Save to phone'.tr),
        onPressed: () => saveToPhone(files),
      ),
      FilledButton.icon(
        icon: const Icon(Icons.share),
        label: Text('Share'.tr),
        onPressed: () => shareFiles(files, text: shareText),
      ),
    ],
  ));
}

/// مؤشر تقدم أثناء عملية طويلة
Future<T?> runWithProgress<T>(String msg, RxInt progress, Future<T> Function() job) async {
  Get.dialog(
    PopScope(
      canPop: false,
      child: AlertDialog(
        content: Obx(() => Row(children: [
              const CircularProgressIndicator(),
              const SizedBox(width: 20),
              Expanded(child: Text(progress.value > 0 ? '$msg (${progress.value})' : msg)),
            ])),
      ),
    ),
    barrierDismissible: false,
  );
  try {
    return await job();
  } catch (e) {
    toast('Error'.tr, 'Operation failed: @e'.trParams({'e': '$e'}), error: true);
    return null;
  } finally {
    if (Get.isDialogOpen == true) Get.back();
  }
}
