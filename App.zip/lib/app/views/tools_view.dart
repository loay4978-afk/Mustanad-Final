import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart' show DateFormat;
import 'package:path/path.dart' as p;

import '../controllers/app_controller.dart';
import '../controllers/docs_controller.dart';
import '../controllers/tools_controller.dart';
import '../core/utils.dart';
import '../data/models/models.dart';
import 'doc_detail_view.dart';
import 'file_result.dart';
import 'nav.dart';
import 'word_flow.dart';

class ToolsView extends StatelessWidget {
  const ToolsView({super.key});

  // ───────── أدوات المستندات داخل التطبيق ─────────
  Future<void> _mergeDocs() async {
    final dc = Get.find<DocsController>();
    if (dc.docs.length < 2) {
      toast('Notice'.tr, 'You need at least two documents'.tr, error: true);
      return;
    }
    final chosen = <int>[];
    final ok = await Get.dialog<bool>(StatefulBuilder(
      builder: (ctx, setState) => AlertDialog(
        title: Text('Select documents to merge'.tr),
        content: SizedBox(
          width: double.maxFinite,
          child: ListView(shrinkWrap: true, children: [
            for (final d in dc.docs)
              CheckboxListTile(
                value: chosen.contains(d.id),
                title: Text(d.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                subtitle: Text('@n pages'.trParams({'n': '${d.pageCount}'})),
                onChanged: (v) => setState(() => v == true ? chosen.add(d.id) : chosen.remove(d.id)),
              ),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Get.back(result: false), child: Text('Cancel'.tr)),
          FilledButton(onPressed: chosen.length < 2 ? null : () => Get.back(result: true), child: Text('Merge'.tr)),
        ],
      ),
    ));
    if (ok != true) return;
    final title = await askText('New document title'.tr, initial: 'Merged ${DateFormat('yyyy-MM-dd').format(DateTime.now())}');
    if (title == null || title.trim().isEmpty) return;
    final id = await dc.mergeDocs(chosen, title.trim(), null);
    Get.to(() => DocDetailView(docId: id));
  }

  Future<void> _splitDoc() async {
    final dc = Get.find<DocsController>();
    if (dc.docs.isEmpty) return;
    final d = await Get.dialog<DocModel>(SimpleDialog(title: Text('Choose a document'.tr), children: [
      for (final x in dc.docs) SimpleDialogOption(onPressed: () => Get.back(result: x), child: Text('${x.title} (${x.pageCount})')),
    ]));
    if (d == null) return;
    final r = await askText('Pages to extract, e.g. 1-3,5'.tr, hint: '1-3,5');
    if (r == null) return;
    final pages = await dc.pages(d.id);
    final idx = parseRanges(r, pages.length);
    if (idx.isEmpty) {
      toast('Notice'.tr, 'No valid pages selected'.tr, error: true);
      return;
    }
    final t = await askText('New document title'.tr, initial: '${d.title} (part)');
    if (t == null || t.trim().isEmpty) return;
    final id = await dc.extractPages([for (final i in idx) pages[i - 1]], t.trim(), d.folderId);
    if (id != null) Get.to(() => DocDetailView(docId: id));
  }

  // ───────── أدوات ملفات PDF ─────────
  Future<void> _mergePdfs() async {
    final r = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['pdf'], allowMultiple: true);
    if (r == null) return;
    final paths = r.files.map((f) => f.path).whereType<String>().toList();
    if (paths.length < 2) {
      toast('Notice'.tr, 'Select at least two PDF files'.tr, error: true);
      return;
    }
    final nameCtrl = TextEditingController(text: 'merged');
    final ok = await Get.dialog<bool>(StatefulBuilder(
      builder: (ctx, setState) => AlertDialog(
        title: Text('Merge PDF files'.tr),
        content: SizedBox(
          width: double.maxFinite,
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            TextField(controller: nameCtrl, decoration: InputDecoration(labelText: 'Output name'.tr)),
            const SizedBox(height: 12),
            Text('Files to merge (drag to reorder)'.tr, style: Theme.of(ctx).textTheme.bodySmall),
            SizedBox(
              height: _listHeight(paths.length),
              child: ReorderableListView(
                shrinkWrap: true,
                onReorder: (o, n) => setState(() {
                  if (n > o) n--;
                  paths.insert(n, paths.removeAt(o));
                }),
                children: [
                  for (final f in paths)
                    ListTile(
                      key: ValueKey(f),
                      dense: true,
                      leading: const Icon(Icons.picture_as_pdf, size: 20),
                      title: Text(p.basename(f), maxLines: 1, overflow: TextOverflow.ellipsis),
                      trailing: const Icon(Icons.drag_handle),
                    ),
                ],
              ),
            ),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Get.back(result: false), child: Text('Cancel'.tr)),
          FilledButton(onPressed: () => Get.back(result: true), child: Text('Merge'.tr)),
        ],
      ),
    ));
    if (ok != true) return;
    final progress = 0.obs;
    final File? f = await runWithProgress<File>('Merging…'.tr, progress,
        () => Get.find<ToolsController>().mergePdfs(paths, nameCtrl.text.trim().isEmpty ? 'merged' : nameCtrl.text.trim(), progress: progress));
    if (f != null) {
      await showFileResult([f],
          note: 'Pages are rendered as images, so text may no longer be selectable.'.tr, shareText: p.basenameWithoutExtension(f.path));
    }
  }

  double _listHeight(int n) => (n * 56.0).clamp(112.0, 280.0);

  Future<void> _splitPdf() async {
    final r = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['pdf']);
    final path = r?.files.single.path;
    if (path == null) return;
    final rangesCtrl = TextEditingController();
    var each = false;
    final ok = await Get.dialog<bool>(StatefulBuilder(
      builder: (ctx, setState) => AlertDialog(
        title: Text('Split PDF file'.tr),
        content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: Text('Split each page into its own file'.tr),
            value: each,
            onChanged: (v) => setState(() => each = v),
          ),
          if (!each) ...[
            TextField(
              controller: rangesCtrl,
              decoration: InputDecoration(labelText: 'Ranges, e.g. 1-3; 4-6 (each range becomes a file)'.tr, hintText: '1-3; 4-6'),
            ),
          ],
        ]),
        actions: [
          TextButton(onPressed: () => Get.back(result: false), child: Text('Cancel'.tr)),
          FilledButton(onPressed: () => Get.back(result: true), child: Text('Split'.tr)),
        ],
      ),
    ));
    if (ok != true) return;
    if (!each && rangesCtrl.text.trim().isEmpty) {
      toast('Notice'.tr, 'No valid pages selected'.tr, error: true);
      return;
    }
    final progress = 0.obs;
    final List<File>? files = await runWithProgress<List<File>>('Splitting…'.tr, progress,
        () => Get.find<ToolsController>().splitPdf(path, p.basenameWithoutExtension(path), rangesCtrl.text, each, progress: progress));
    if (files == null) return;
    if (files.isEmpty) {
      toast('Notice'.tr, 'No valid pages selected'.tr, error: true);
      return;
    }
    await showFileResult(files, note: 'Pages are rendered as images, so text may no longer be selectable.'.tr);
  }

  Future<void> _compress() async {
    final r = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['pdf']);
    final path = r?.files.single.path;
    if (path == null) return;
    var q = 1;
    final ok = await Get.dialog<bool>(StatefulBuilder(
      builder: (ctx, setState) => AlertDialog(
        title: Text('Compress PDF'.tr),
        content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Wrap(spacing: 8, children: [
            ChoiceChip(label: Text('Medium (smaller)'.tr), selected: q == 1, onSelected: (_) => setState(() => q = 1)),
            ChoiceChip(label: Text('Low (smallest)'.tr), selected: q == 2, onSelected: (_) => setState(() => q = 2)),
            ChoiceChip(label: Text('Minimal (tiny)'.tr), selected: q == 3, onSelected: (_) => setState(() => q = 3)),
          ]),
          const SizedBox(height: 10),
          Text('Compression turns pages into images, so text may no longer be selectable.'.tr, style: Theme.of(ctx).textTheme.bodySmall),
        ]),
        actions: [
          TextButton(onPressed: () => Get.back(result: false), child: Text('Cancel'.tr)),
          FilledButton(onPressed: () => Get.back(result: true), child: Text('Compress'.tr)),
        ],
      ),
    ));
    if (ok != true) return;
    final before = File(path).lengthSync();
    final progress = 0.obs;
    final File? out = await runWithProgress<File>('Compressing…'.tr, progress,
        () => Get.find<ToolsController>().compressPdf(path, '${p.basenameWithoutExtension(path)}_compressed', q, progress: progress));
    if (out == null) return;
    final after = out.lengthSync();
    final note = '${'Original: @a  →  Compressed: @b'.trParams({'a': fmtBytes(before), 'b': fmtBytes(after)})}'
        '${after >= before ? '\n${'Compressed file is not smaller than the original. This PDF is probably already optimized.'.tr}' : ''}';
    await showFileResult([out], note: note);
  }

  Future<void> _backup() async {
    final app = Get.find<AppController>();
    if (!await app.requirePro('Backup and restore')) return;
    final progress = 0.obs;
    final File? f = await runWithProgress<File>('Creating backup…'.tr, progress, () => Get.find<ToolsController>().backup());
    if (f != null) await showFileResult([f], note: 'Backup ready: @s'.trParams({'s': fmtBytes(f.lengthSync())}));
  }

  Future<void> _restore() async {
    final app = Get.find<AppController>();
    if (!await app.requirePro('Backup and restore')) return;
    final r = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['zip']);
    final path = r?.files.single.path;
    if (path == null) return;
    if (!await confirm('Restore backup'.tr, 'All current documents will be replaced. Continue?'.tr)) return;
    final progress = 0.obs;
    final n = await runWithProgress<int>('Restoring…'.tr, progress, () => Get.find<ToolsController>().restore(path));
    if (n != null) toast('Backup'.tr, 'Backup restored'.tr);
  }

  @override
  Widget build(BuildContext context) {
    Widget tile(IconData i, String t, String s, VoidCallback onTap, {bool pro = false}) => Card(
          child: ListTile(
            leading: CircleAvatar(child: Icon(i)),
            title: Row(children: [
              Flexible(child: Text(t.tr)),
              if (pro) ...[const SizedBox(width: 6), const Icon(Icons.workspace_premium, size: 16, color: Colors.amber)],
            ]),
            subtitle: Text(s.tr),
            onTap: onTap,
          ),
        );
    Widget section(String t) => Padding(
          padding: const EdgeInsets.fromLTRB(8, 14, 8, 4),
          child: Text(t.tr, style: TextStyle(fontWeight: FontWeight.bold, color: Theme.of(context).colorScheme.primary)),
        );

    return Scaffold(
      appBar: AppBar(title: Text('Tools'.tr)),
      body: ListView(padding: const EdgeInsets.all(12), children: [
        section('My documents'),
        tile(Icons.merge_type, 'Merge documents', 'Combine several documents into one', _mergeDocs),
        tile(Icons.call_split, 'Split document', 'Extract selected pages into a new document', _splitDoc),
        tile(Icons.photo_library_outlined, 'Import images', 'Convert photos into a document', () => startImport()),
        section('PDF files'),
        tile(Icons.picture_as_pdf, 'Import PDF', 'Turn PDF pages into an editable document', () => startPdfImport()),
        tile(Icons.merge, 'Merge PDF files', 'Pick several PDFs and combine them', _mergePdfs),
        tile(Icons.content_cut, 'Split PDF file', 'Extract pages from a PDF file', _splitPdf),
        tile(Icons.compress, 'Compress PDF file', 'Reduce the size of a PDF', _compress),
        tile(Icons.description_outlined, 'PDF to Word', 'Convert a PDF to an editable Word file', pdfToWordFlow),
        section('Backup'),
        tile(Icons.cloud_upload_outlined, 'Backup', 'Save all documents as a file to any cloud', _backup, pro: true),
        tile(Icons.cloud_download_outlined, 'Restore backup', 'Restore documents from a backup file', _restore, pro: true),
      ]),
    );
  }
}
