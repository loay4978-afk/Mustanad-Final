import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../controllers/app_controller.dart';
import '../controllers/docs_controller.dart';
import '../core/pdf_service.dart';
import '../core/utils.dart';
import '../data/models/models.dart';
import 'file_result.dart';

/// خيارات التصدير ثم بناء PDF ومشاركته
Future<void> exportFlow(DocModel doc, List<PageModel> pages, {bool ask = true}) async {
  if (pages.isEmpty) return;
  final app = Get.find<AppController>();
  final dc = Get.find<DocsController>();
  var q = app.pdfQuality.value;
  var size = app.pdfSize.value;

  if (ask) {
    final ok = await Get.dialog<bool>(StatefulBuilder(
      builder: (ctx, setState) => AlertDialog(
        title: Text('Export PDF'.tr),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Quality'.tr, style: const TextStyle(fontWeight: FontWeight.bold)),
            Wrap(spacing: 8, children: [
              for (final e in {0: 'High', 1: 'Medium (smaller)', 2: 'Low (smallest)'}.entries)
                ChoiceChip(label: Text(e.value.tr), selected: q == e.key, onSelected: (_) => setState(() => q = e.key)),
            ]),
            const SizedBox(height: 16),
            Text('Page size'.tr, style: const TextStyle(fontWeight: FontWeight.bold)),
            Wrap(spacing: 8, children: [
              for (final e in {'fit': 'Fit to image', 'a4': 'A4', 'letter': 'Letter'}.entries)
                ChoiceChip(label: Text(e.value.tr), selected: size == e.key, onSelected: (_) => setState(() => size = e.key)),
            ]),
            if (!app.isPro.value) ...[
              const SizedBox(height: 12),
              Text('Free version adds a small watermark. Pro removes it.'.tr, style: Theme.of(ctx).textTheme.bodySmall),
            ],
          ],
        ),
        actions: [
          TextButton(onPressed: () => Get.back(result: false), child: Text('Cancel'.tr)),
          FilledButton(onPressed: () => Get.back(result: true), child: Text('Export'.tr)),
        ],
      ),
    ));
    if (ok != true) return;
  }

  Get.dialog(
    AlertDialog(content: Row(children: [const CircularProgressIndicator(), const SizedBox(width: 20), Expanded(child: Text('Building PDF…'.tr))])),
    barrierDismissible: false,
  );
  try {
    final File f = await dc.exportPdf(doc, pages, PdfOptions(quality: q, size: size));
    Get.back();
    await showFileResult([f], shareText: doc.title);
  } catch (e) {
    if (Get.isDialogOpen == true) Get.back();
    toast('PDF', 'Could not create the PDF'.tr, error: true);
  }
}
