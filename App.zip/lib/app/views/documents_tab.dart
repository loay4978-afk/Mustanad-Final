import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../controllers/docs_controller.dart';
import '../core/utils.dart';
import '../data/models/models.dart';
import 'doc_detail_view.dart';
import 'nav.dart';
import 'widgets/common.dart';

class DocumentsTab extends StatelessWidget {
  const DocumentsTab({super.key});

  void _scanSheet() {
    Get.bottomSheet(
      SafeArea(
        child: Wrap(children: [
          ListTile(
            leading: const Icon(Icons.document_scanner_outlined),
            title: Text('Scan with camera'.tr),
            onTap: () {
              Get.back();
              startScan();
            },
          ),
          ListTile(
            leading: const Icon(Icons.photo_library_outlined),
            title: Text('Import images'.tr),
            onTap: () {
              Get.back();
              startImport();
            },
          ),
          ListTile(
            leading: const Icon(Icons.picture_as_pdf_outlined),
            title: Text('Import PDF'.tr),
            onTap: () {
              Get.back();
              startPdfImport();
            },
          ),
        ]),
      ),
      backgroundColor: Theme.of(Get.context!).colorScheme.surface,
    );
  }

  Future<void> _folderMenu(DocsController dc, FolderModel f) async {
    final a = await Get.dialog<String>(SimpleDialog(title: Text(f.name), children: [
      SimpleDialogOption(onPressed: () => Get.back(result: 'rename'), child: Text('Rename'.tr)),
      SimpleDialogOption(onPressed: () => Get.back(result: 'delete'), child: Text('Delete'.tr)),
    ]));
    if (a == 'rename') {
      final n = await askText('Rename'.tr, initial: f.name);
      if (n != null && n.trim().isNotEmpty) await dc.renameFolder(f, n.trim());
    } else if (a == 'delete') {
      if (await confirm('Delete folder'.tr, 'Documents inside will be kept.'.tr)) await dc.deleteFolder(f);
    }
  }

  Future<void> _open(DocModel d) async {
    if (await ensureUnlocked(d)) Get.to(() => DocDetailView(docId: d.id));
  }

  @override
  Widget build(BuildContext context) {
    final dc = Get.find<DocsController>();
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(
        title: Text('Mustanad'.tr),
        actions: [
          Obx(() => IconButton(
                icon: Icon(dc.favOnly.value ? Icons.star : Icons.star_border),
                tooltip: 'Favorites'.tr,
                onPressed: () => dc.favOnly.toggle(),
              )),
          PopupMenuButton<String>(
            icon: const Icon(Icons.sort),
            onSelected: (v) => dc.sort.value = v,
            itemBuilder: (_) => [
              PopupMenuItem(value: 'date', child: Text('Sort by date'.tr)),
              PopupMenuItem(value: 'name', child: Text('Sort by name'.tr)),
            ],
          ),
          Obx(() => IconButton(
                icon: Icon(dc.grid.value ? Icons.view_list : Icons.grid_view),
                onPressed: () => dc.grid.toggle(),
              )),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _scanSheet,
        icon: const Icon(Icons.document_scanner),
        label: Text('Scan'.tr),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
            child: TextField(
              onChanged: (v) => dc.query.value = v,
              decoration: InputDecoration(
                hintText: 'Search documents and text inside them'.tr,
                prefixIcon: const Icon(Icons.search),
                isDense: true,
              ),
            ),
          ),
          Obx(() => SizedBox(
                height: 44,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  children: [
                    Padding(
                      padding: const EdgeInsetsDirectional.only(end: 8),
                      child: ChoiceChip(
                        label: Text('All'.tr),
                        selected: dc.folderFilter.value == null,
                        onSelected: (_) => dc.folderFilter.value = null,
                      ),
                    ),
                    for (final f in dc.folders)
                      Padding(
                        padding: const EdgeInsetsDirectional.only(end: 8),
                        child: GestureDetector(
                          onLongPress: () => _folderMenu(dc, f),
                          child: ChoiceChip(
                            avatar: const Icon(Icons.folder, size: 18),
                            label: Text(f.name),
                            selected: dc.folderFilter.value == f.id,
                            onSelected: (_) => dc.folderFilter.value = f.id,
                          ),
                        ),
                      ),
                    ActionChip(
                      avatar: const Icon(Icons.create_new_folder_outlined, size: 18),
                      label: Text('New folder'.tr),
                      onPressed: () async {
                        final n = await askText('New folder'.tr);
                        if (n != null && n.trim().isNotEmpty) await dc.createFolder(n.trim());
                      },
                    ),
                  ],
                ),
              )),
          Obx(() {
            final tags = dc.allTags;
            if (tags.isEmpty) return const SizedBox.shrink();
            return SizedBox(
              height: 40,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 12),
                children: [
                  for (final t in tags)
                    Padding(
                      padding: const EdgeInsetsDirectional.only(end: 8),
                      child: FilterChip(
                        label: Text('#$t'),
                        selected: dc.tagFilter.value == t,
                        onSelected: (v) => dc.tagFilter.value = v ? t : '',
                      ),
                    ),
                ],
              ),
            );
          }),
          Expanded(
            child: Obx(() {
              final list = dc.visible;
              if (list.isEmpty) {
                return Center(
                  child: Padding(
                    padding: const EdgeInsets.all(32),
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                      Icon(Icons.document_scanner_outlined, size: 64, color: cs.outline),
                      const SizedBox(height: 12),
                      Text(dc.docs.isEmpty ? 'No documents yet. Tap Scan to start.'.tr : 'No matching documents'.tr, textAlign: TextAlign.center),
                    ]),
                  ),
                );
              }
              if (dc.grid.value) {
                return GridView.builder(
                  padding: const EdgeInsets.fromLTRB(12, 4, 12, 96),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, childAspectRatio: 0.78, crossAxisSpacing: 10, mainAxisSpacing: 10),
                  itemCount: list.length,
                  itemBuilder: (_, i) => _GridCard(doc: list[i], onTap: () => _open(list[i])),
                );
              }
              return ListView.builder(
                padding: const EdgeInsets.only(bottom: 96),
                itemCount: list.length,
                itemBuilder: (_, i) => _DocTile(doc: list[i], onTap: () => _open(list[i])),
              );
            }),
          ),
        ],
      ),
    );
  }
}

class _DocTile extends StatelessWidget {
  final DocModel doc;
  final VoidCallback onTap;
  const _DocTile({required this.doc, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final dc = Get.find<DocsController>();
    final snip = dc.snippetFor(doc);
    return ListTile(
      onTap: onTap,
      leading: ClipRRect(
        borderRadius: BorderRadius.circular(6),
        child: SizedBox(
          width: 52,
          height: 68,
          child: doc.locked ? const Center(child: Icon(Icons.lock_outline)) : FileThumb(path: doc.cover),
        ),
      ),
      title: Row(children: [
        Expanded(child: Text(doc.title, maxLines: 1, overflow: TextOverflow.ellipsis)),
        if (doc.favorite) const Icon(Icons.star, size: 16, color: Colors.amber),
      ]),
      subtitle: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('@n pages • @d'.trParams({'n': '${doc.pageCount}', 'd': fmtDate(doc.updatedAt)}), style: Theme.of(context).textTheme.bodySmall),
        if (snip.isNotEmpty) Text(snip, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(color: Theme.of(context).colorScheme.primary, fontSize: 12)),
        if (doc.tags.isNotEmpty) Text(doc.tags.map((t) => '#$t').join(' '), style: Theme.of(context).textTheme.bodySmall),
      ]),
      trailing: Obx(() => dc.ocrRunning.contains(doc.id)
          ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
          : const SizedBox.shrink()),
    );
  }
}

class _GridCard extends StatelessWidget {
  final DocModel doc;
  final VoidCallback onTap;
  const _GridCard({required this.doc, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Expanded(child: doc.locked ? const Center(child: Icon(Icons.lock_outline, size: 40)) : FileThumb(path: doc.cover)),
          Padding(
            padding: const EdgeInsets.all(8),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(doc.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600)),
              Text('@n pages'.trParams({'n': '${doc.pageCount}'}), style: Theme.of(context).textTheme.bodySmall),
            ]),
          ),
        ]),
      ),
    );
  }
}
