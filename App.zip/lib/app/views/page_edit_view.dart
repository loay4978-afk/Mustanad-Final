import 'dart:async';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../controllers/app_controller.dart';
import '../core/utils.dart';
import '../data/models/models.dart';
import '../engine/scanner_engine.dart';

const List<String> kFilterNames = ['Original', 'Auto', 'Magic color', 'Black and white', 'Grayscale'];

/// شاشة التحرير: قص يدوي مع اكتشاف تلقائي + فلاتر + سطوع/تباين + تدوير
class PageEditView extends StatefulWidget {
  final PageEdit edit;
  const PageEditView({super.key, required this.edit});
  @override
  State<PageEditView> createState() => _PageEditViewState();
}

class _PageEditViewState extends State<PageEditView> {
  late final PageEdit e = widget.edit;
  late final List<double> _initialCorners = List.of(widget.edit.corners);
  bool crop = true;
  Uint8List? preview;
  List<Uint8List>? thumbs;
  int _token = 0;
  Timer? _debounce;
  bool _detecting = false;

  @override
  void dispose() {
    _debounce?.cancel();
    super.dispose();
  }

  Map<String, Object?> _args(int maxSide, int quality) => {
        'path': e.origPath,
        'corners': e.corners,
        'filter': e.filter,
        'rotation': e.rotation,
        'brightness': e.brightness,
        'contrast': e.contrast,
        'maxSide': maxSide,
        'quality': quality,
      };

  void _schedulePreview() {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 250), _refreshPreview);
  }

  Future<void> _refreshPreview() async {
    final t = ++_token;
    final r = await compute<Map<String, Object?>, Map<String, Object?>>(processEntry, _args(1400, 80));
    if (!mounted || t != _token) return;
    setState(() => preview = r['bytes'] as Uint8List);
  }

  Future<void> _refreshThumbs() async {
    final r = await compute<Map<String, Object?>, Map<String, Object?>>(previewFiltersEntry, {
      'path': e.origPath,
      'corners': e.corners,
      'rotation': e.rotation,
    });
    if (!mounted) return;
    setState(() => thumbs = (r['thumbs'] as List).cast<Uint8List>());
  }

  void _setMode(bool toCrop) {
    setState(() => crop = toCrop);
    if (!toCrop) {
      preview = null;
      _refreshPreview();
      _refreshThumbs();
    }
  }

  Future<void> _auto() async {
    setState(() => _detecting = true);
    final r = await compute<Map<String, Object?>, Map<String, Object?>>(detectEntry, {'path': e.origPath});
    if (!mounted) return;
    setState(() {
      e.corners = (r['corners'] as List).cast<double>();
      _detecting = false;
    });
    if (r['found'] != true) {
      Get.snackbar('Scan'.tr, 'Could not find the document edges. Adjust the corners manually.'.tr, snackPosition: SnackPosition.BOTTOM);
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(
        title: Text(crop ? 'Crop'.tr : 'Enhance'.tr),
        actions: [IconButton(icon: const Icon(Icons.check), onPressed: () => Get.back(result: e))],
      ),
      body: Column(children: [
        Expanded(
          child: Container(
            color: Colors.black12,
            padding: const EdgeInsets.all(8),
            child: crop
                ? _CropArea(edit: e, onChanged: () => setState(() {}))
                : Center(
                    child: preview == null
                        ? const CircularProgressIndicator()
                        : Image.memory(preview!, gaplessPlayback: true, fit: BoxFit.contain)),
          ),
        ),
        Container(
          color: cs.surface,
          child: SafeArea(
            top: false,
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              if (crop)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 8),
                  child: Wrap(spacing: 8, runSpacing: 4, alignment: WrapAlignment.center, children: [
                    FilledButton.tonalIcon(
                      onPressed: _detecting ? null : _auto,
                      icon: _detecting
                          ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                          : const Icon(Icons.auto_fix_high),
                      label: Text('Auto detect'.tr),
                    ),
                    OutlinedButton.icon(
                      onPressed: () => setState(() => e.corners = [0, 0, 1, 0, 1, 1, 0, 1]),
                      icon: const Icon(Icons.crop_free),
                      label: Text('Full page'.tr),
                    ),
                    OutlinedButton.icon(
                      onPressed: () => setState(() => e.corners = List.of(_initialCorners)),
                      icon: const Icon(Icons.restart_alt),
                      label: Text('Reset'.tr),
                    ),
                  ]),
                )
              else ...[
                SizedBox(
                  height: 108,
                  child: thumbs == null
                      ? const Center(child: CircularProgressIndicator())
                      : ListView.builder(
                          scrollDirection: Axis.horizontal,
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                          itemCount: kFilterCount,
                          itemBuilder: (_, i) => GestureDetector(
                            onTap: () {
                              setState(() => e.filter = i);
                              _refreshPreview();
                            },
                            child: Container(
                              width: 74,
                              margin: const EdgeInsets.symmetric(horizontal: 4),
                              decoration: BoxDecoration(
                                border: Border.all(color: e.filter == i ? cs.primary : Colors.transparent, width: 2),
                                borderRadius: BorderRadius.circular(6),
                              ),
                              child: Column(children: [
                                Expanded(child: ClipRRect(borderRadius: BorderRadius.circular(4), child: Image.memory(thumbs![i], fit: BoxFit.cover, width: 70))),
                                Padding(
                                  padding: const EdgeInsets.symmetric(vertical: 2),
                                  child: Text(kFilterNames[i].tr, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 10)),
                                ),
                              ]),
                            ),
                          ),
                        ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  child: Row(children: [
                    const Icon(Icons.brightness_6_outlined, size: 20),
                    Expanded(
                      child: Slider(
                        value: e.brightness,
                        min: -0.3,
                        max: 0.3,
                        onChanged: (v) => setState(() => e.brightness = v),
                        onChangeEnd: (_) => _schedulePreview(),
                      ),
                    ),
                    const Icon(Icons.contrast, size: 20),
                    Expanded(
                      child: Slider(
                        value: e.contrast,
                        min: 0.7,
                        max: 1.6,
                        onChanged: (v) => setState(() => e.contrast = v),
                        onChangeEnd: (_) => _schedulePreview(),
                      ),
                    ),
                  ]),
                ),
                Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  TextButton.icon(
                    icon: const Icon(Icons.bookmark_add_outlined, size: 18),
                    label: Text('Set as default'.tr),
                    onPressed: () async {
                      await Get.find<AppController>().setDefaults(filter: e.filter, brightness: e.brightness, contrast: e.contrast);
                      toast('Scanning'.tr, 'Saved as the default scan mode'.tr);
                    },
                  ),
                  IconButton(
                    icon: const Icon(Icons.rotate_left),
                    onPressed: () {
                      setState(() => e.rotation = (e.rotation + 3) % 4);
                      _refreshPreview();
                      _refreshThumbs();
                    },
                  ),
                  IconButton(
                    icon: const Icon(Icons.rotate_right),
                    onPressed: () {
                      setState(() => e.rotation = (e.rotation + 1) % 4);
                      _refreshPreview();
                      _refreshThumbs();
                    },
                  ),
                ]),
              ],
              SegmentedButton<bool>(
                segments: [
                  ButtonSegment(value: true, icon: const Icon(Icons.crop), label: Text('Crop'.tr)),
                  ButtonSegment(value: false, icon: const Icon(Icons.tune), label: Text('Enhance'.tr)),
                ],
                selected: {crop},
                onSelectionChanged: (s) => _setMode(s.first),
              ),
              const SizedBox(height: 8),
            ]),
          ),
        ),
      ]),
    );
  }
}

class _CropArea extends StatefulWidget {
  final PageEdit edit;
  final VoidCallback onChanged;
  const _CropArea({required this.edit, required this.onChanged});
  @override
  State<_CropArea> createState() => _CropAreaState();
}

class _CropAreaState extends State<_CropArea> {
  int? _drag;

  @override
  Widget build(BuildContext context) {
    final e = widget.edit;
    return LayoutBuilder(builder: (ctx, cons) {
      final iw = math.max(1, e.origW).toDouble(), ih = math.max(1, e.origH).toDouble();
      final scale = math.min(cons.maxWidth / iw, cons.maxHeight / ih);
      final dw = iw * scale, dh = ih * scale;
      final ox = (cons.maxWidth - dw) / 2, oy = (cons.maxHeight - dh) / 2;
      Offset pt(int i) => Offset(ox + e.corners[2 * i] * dw, oy + e.corners[2 * i + 1] * dh);

      return GestureDetector(
        behavior: HitTestBehavior.opaque,
        onPanStart: (d) {
          var best = -1;
          var bd = 56.0;
          for (var i = 0; i < 4; i++) {
            final dist = (pt(i) - d.localPosition).distance;
            if (dist < bd) {
              bd = dist;
              best = i;
            }
          }
          _drag = best >= 0 ? best : null;
        },
        onPanUpdate: (d) {
          final i = _drag;
          if (i == null) return;
          e.corners[2 * i] = ((d.localPosition.dx - ox) / dw).clamp(0.0, 1.0);
          e.corners[2 * i + 1] = ((d.localPosition.dy - oy) / dh).clamp(0.0, 1.0);
          setState(() {});
          widget.onChanged();
        },
        onPanEnd: (_) => _drag = null,
        child: Stack(children: [
          Positioned(
            left: ox,
            top: oy,
            width: dw,
            height: dh,
            child: Image.file(File(e.origPath), fit: BoxFit.fill, cacheWidth: 1600, gaplessPlayback: true),
          ),
          Positioned.fill(child: CustomPaint(painter: _QuadPainter([for (var i = 0; i < 4; i++) pt(i)], _drag))),
        ]),
      );
    });
  }
}

class _QuadPainter extends CustomPainter {
  final List<Offset> pts;
  final int? active;
  _QuadPainter(this.pts, this.active);

  @override
  void paint(Canvas canvas, Size size) {
    final path = Path()..moveTo(pts[0].dx, pts[0].dy);
    for (var i = 1; i < 4; i++) {
      path.lineTo(pts[i].dx, pts[i].dy);
    }
    path.close();
    canvas.drawPath(path, Paint()..color = Colors.blue.withOpacity(0.15));
    canvas.drawPath(path, Paint()..color = Colors.blueAccent..style = PaintingStyle.stroke..strokeWidth = 2.5);
    for (var i = 0; i < 4; i++) {
      canvas.drawCircle(pts[i], i == active ? 18 : 14, Paint()..color = Colors.white);
      canvas.drawCircle(pts[i], i == active ? 18 : 14, Paint()..color = Colors.blueAccent..style = PaintingStyle.stroke..strokeWidth = 3);
    }
  }

  @override
  bool shouldRepaint(covariant _QuadPainter old) => true;
}
