import 'package:file_picker/file_picker.dart';
import 'package:get/get.dart';

import '../controllers/scan_controller.dart';
import '../core/utils.dart';
import 'camera_view.dart';
import 'review_view.dart';

Future<void> startScan({int? targetDoc}) async {
  final sc = Get.find<ScanController>();
  sc.clear();
  sc.targetDocId = targetDoc;
  await Get.to(() => const CameraView());
}

Future<void> startImport({int? targetDoc}) async {
  final sc = Get.find<ScanController>();
  sc.clear();
  sc.targetDocId = targetDoc;
  final n = await sc.pickFromGallery();
  if (n > 0) await Get.to(() => const ReviewView());
}

Future<void> startPdfImport({int? targetDoc, bool multiple = false}) async {
  final sc = Get.find<ScanController>();
  final r = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['pdf'], allowMultiple: multiple);
  if (r == null || r.files.isEmpty) return;
  sc.clear();
  sc.targetDocId = targetDoc;
  toast('PDF', 'Importing pages…'.tr);
  Get.to(() => const ReviewView());
  for (final f in r.files) {
    if (f.path != null) await sc.addPdf(f.path!);
  }
}
