import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:share_plus/share_plus.dart';
import 'package:flutter/services.dart';

import '../controllers/app_controller.dart';
import '../controllers/docs_controller.dart';
import '../core/invoice_parser.dart';
import '../core/ocr_service.dart';
import '../core/pdf_service.dart';
import '../core/storage.dart';
import '../core/utils.dart';
import '../data/db/app_db.dart';
import '../data/models/models.dart';

Future<void> _shareText(String name, String text) async {
  final f = await Storage.tempFile('${PdfService.safeName(name)}.txt');
  await f.writeAsString(text);
  await Share.shareXFiles([XFile(f.path)]);
}

/// نص المستند كاملاً بعد OCR
class DocTextView extends StatelessWidget {
  final int docId;
  const DocTextView({super.key, required this.docId});

  @override
  Widget build(BuildContext context) {
    final dc = Get.find<DocsController>();
    final app = Get.find<AppController>();
    return Obx(() {
      final d = dc.docs.firstWhereOrNull((x) => x.id == docId);
      if (d == null) return const Scaffold();
      final running = dc.ocrRunning.contains(docId);
      return Scaffold(
        appBar: AppBar(
          title: Text('Recognized text'.tr),
          actions: [
            IconButton(
              icon: const Icon(Icons.copy),
              onPressed: d.ocrText.isEmpty
                  ? null
                  : () {
                      Clipboard.setData(ClipboardData(text: d.ocrText));
                      toast('OCR', 'Copied'.tr);
                    },
            ),
            IconButton(icon: const Icon(Icons.ios_share), onPressed: d.ocrText.isEmpty ? null : () => _shareText(d.title, d.ocrText)),
          ],
        ),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          Text('OCR languages'.tr, style: const TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          Obx(() => Wrap(spacing: 8, children: [
                for (final e in OcrService.languages.entries)
                  FilterChip(
                    label: Text(e.value),
                    selected: app.ocrLangs.contains(e.key),
                    onSelected: (v) {
                      final l = app.ocrLangs.toList();
                      v ? l.add(e.key) : l.remove(e.key);
                      app.setOcrLangs(l);
                    },
                  ),
              ])),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: running ? null : () => dc.runOcr(docId, force: true),
            icon: running ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.text_snippet_outlined),
            label: Text(running ? 'Recognizing…'.tr : 'Run OCR'.tr),
          ),
          const Divider(height: 32),
          d.ocrText.isEmpty
              ? Text('No text yet. Run OCR to extract text from the pages.'.tr)
              : SelectableText(d.ocrText, style: const TextStyle(fontSize: 15, height: 1.5)),
        ]),
      );
    });
  }
}

/// نص صفحة واحدة
class PageTextView extends StatefulWidget {
  final PageModel page;
  const PageTextView({super.key, required this.page});
  @override
  State<PageTextView> createState() => _PageTextViewState();
}

class _PageTextViewState extends State<PageTextView> {
  late String text = widget.page.ocrText;
  bool busy = false;

  Future<void> _run() async {
    setState(() => busy = true);
    try {
      final t = await OcrService.recognize(widget.page.displayPath, Get.find<AppController>().ocrLangs.toList());
      await AppDb.instance.updatePage(widget.page.id, {'ocr_text': t});
      Get.find<DocsController>().runOcr(widget.page.docId);
      setState(() => text = t);
    } catch (e) {
      toast('OCR', 'OCR failed'.tr, error: true);
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Page text'.tr),
        actions: [
          IconButton(
              icon: const Icon(Icons.copy),
              onPressed: text.isEmpty
                  ? null
                  : () {
                      Clipboard.setData(ClipboardData(text: text));
                      toast('OCR', 'Copied'.tr);
                    }),
        ],
      ),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        FilledButton.icon(
          onPressed: busy ? null : _run,
          icon: busy ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.text_snippet_outlined),
          label: Text(busy ? 'Recognizing…'.tr : 'Run OCR'.tr),
        ),
        const SizedBox(height: 16),
        text.isEmpty ? Text('No text yet. Run OCR to extract text from the pages.'.tr) : SelectableText(text, style: const TextStyle(fontSize: 15, height: 1.5)),
      ]),
    );
  }
}

/// استخراج بيانات الفاتورة من نص المستند
class InvoiceView extends StatelessWidget {
  final int docId;
  const InvoiceView({super.key, required this.docId});

  static const labels = {
    'vendor': 'Vendor',
    'invoice_no': 'Invoice number',
    'date': 'Date',
    'currency': 'Currency',
    'subtotal': 'Subtotal',
    'tax_rate': 'Tax rate',
    'tax': 'Tax',
    'total': 'Total',
    'tax_id': 'Tax ID',
    'email': 'Email',
    'phone': 'Phone',
  };

  @override
  Widget build(BuildContext context) {
    final dc = Get.find<DocsController>();
    final d = dc.docs.firstWhereOrNull((x) => x.id == docId);
    if (d == null) return const Scaffold();
    final inv = parseInvoice(d.ocrText);
    final map = inv.toMap();
    return Scaffold(
      appBar: AppBar(
        title: Text('Invoice data'.tr),
        actions: [
          PopupMenuButton<String>(
            icon: const Icon(Icons.ios_share),
            onSelected: (v) async {
              if (v == 'json') {
                await _shareText('${d.title}_invoice', const JsonEncoder.withIndent('  ').convert({...map, 'items': inv.items}));
              } else {
                final f = await Storage.tempFile('${PdfService.safeName(d.title)}_invoice.csv');
                final sb = StringBuffer('\uFEFFfield,value\n');
                map.forEach((k, val) => sb.writeln('$k,"${val.replaceAll('"', '""')}"'));
                for (final it in inv.items) {
                  sb.writeln('item,"${it.replaceAll('"', '""')}"');
                }
                await f.writeAsString(sb.toString());
                await Share.shareXFiles([XFile(f.path)]);
              }
            },
            itemBuilder: (_) => const [PopupMenuItem(value: 'json', child: Text('JSON')), PopupMenuItem(value: 'csv', child: Text('CSV'))],
          ),
        ],
      ),
      body: d.ocrText.isEmpty
          ? Center(child: Padding(padding: const EdgeInsets.all(32), child: Text('Run OCR first to extract invoice data.'.tr, textAlign: TextAlign.center)))
          : ListView(padding: const EdgeInsets.all(12), children: [
              Text('Review the extracted values. OCR can make mistakes.'.tr, style: Theme.of(context).textTheme.bodySmall),
              const SizedBox(height: 8),
              if (map.isEmpty) Padding(padding: const EdgeInsets.all(24), child: Text('No invoice fields found.'.tr)),
              for (final e in labels.entries)
                if (map.containsKey(e.key))
                  Card(
                    child: ListTile(
                      title: Text(e.value.tr, style: Theme.of(context).textTheme.bodySmall),
                      subtitle: Text(map[e.key]!, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                      trailing: IconButton(
                        icon: const Icon(Icons.copy, size: 18),
                        onPressed: () => Clipboard.setData(ClipboardData(text: map[e.key]!)),
                      ),
                    ),
                  ),
              if (inv.items.isNotEmpty) ...[
                Padding(padding: const EdgeInsets.fromLTRB(8, 12, 8, 4), child: Text('Line items (approximate)'.tr, style: const TextStyle(fontWeight: FontWeight.bold))),
                for (final it in inv.items) Card(child: ListTile(dense: true, title: Text(it))),
              ],
            ]),
    );
  }
}
