import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../controllers/app_controller.dart';
import '../controllers/docs_controller.dart';
import '../core/utils.dart';
import '../data/models/models.dart';
import 'export_flow.dart';
import 'nav.dart';
import 'page_viewer_view.dart';
import 'text_views.dart';
import 'word_flow.dart';
import 'widgets/common.dart';

class DocDetailView extends StatefulWidget {
  final int docId;
  const DocDetailView({super.key, required this.docId});
  @override
  State<DocDetailView> createState() => _DocDetailViewState();
}

class _DocDetailViewState extends State<DocDetailView> {
  final dc = Get.find<DocsController>();
  final app = Get.find<AppController>();
  List<PageModel> pages = [];
  final Set<int> sel = {};
  Worker? _w;

  DocModel? get doc => docs.firstWhereOrNull((d) => d.id == widget.docId);
  List<DocModel> get docs => dc.docs;

  @override
  void initState() {
    super.initState();
    _load();
    _w = ever(dc.docs, (_) => _load());
  }

  @override
  void dispose() {
    _w?.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final p = await dc.pages(widget.docId);
    if (!mounted) return;
    setState(() {
      pages = p;
      sel.removeWhere((id) => !p.any((x) => x.id == id));
    });
  }

  Future<void> _more(String v, DocModel d) async {
    switch (v) {
      case 'rename':
        final n = await askText('Rename'.tr, initial: d.title);
        if (n != null && n.trim().isNotEmpty) await dc.renameDoc(d, n.trim());
        break;
      case 'tags':
        final n = await askText('Tags (comma separated)'.tr, initial: d.tags.join(', '));
        if (n != null) await dc.setTags(d, n.split(RegExp(r'[,،]')).map((t) => t.trim()).where((t) => t.isNotEmpty).toList());
        break;
      case 'folder':
        final r = await Get.dialog<int>(SimpleDialog(title: Text('Move to folder'.tr), children: [
          SimpleDialogOption(onPressed: () => Get.back(result: -1), child: Text('No folder'.tr)),
          for (final f in dc.folders) SimpleDialogOption(onPressed: () => Get.back(result: f.id), child: Text(f.name)),
        ]));
        if (r != null) await dc.moveToFolder(d, r == -1 ? null : r);
        break;
      case 'lock':
        if (d.locked) {
          if (await askPin(title: 'Enter PIN'.tr)) await dc.setLocked(d, false);
        } else {
          if (!app.hasPin.value) {
            final p = await askText('Create a PIN (4+ digits)'.tr, obscure: true, keyboard: TextInputType.number);
            if (p == null || p.length < 4) {
              if (p != null) toast('Notice'.tr, 'PIN is too short'.tr, error: true);
              return;
            }
            await app.setPin(p);
            app.sessionUnlocked.value = true;
          }
          await dc.setLocked(d, true);
          dc.unlocked.add(d.id);
        }
        break;
      case 'text':
        Get.to(() => DocTextView(docId: d.id));
        break;
      case 'invoice':
        if (await app.requirePro('Invoice data extraction')) Get.to(() => InvoiceView(docId: d.id));
        break;
      case 'ocr':
        dc.runOcr(d.id, force: true);
        toast('OCR', 'Text recognition started'.tr);
        break;
      case 'export':
        await exportFlow(d, pages);
        break;
      case 'word':
        await docToWordFlow(d, pages);
        break;
      case 'delete':
        if (await confirm('Delete document'.tr, 'This cannot be undone.'.tr)) {
          await dc.deleteDoc(d.id);
          Get.back();
        }
        break;
    }
  }

  Future<void> _extract(DocModel d) async {
    final chosen = pages.where((p) => sel.contains(p.id)).toList();
    final t = await askText('New document title'.tr, initial: '${d.title} (2)');
    if (t == null || t.trim().isEmpty) return;
    final id = await dc.extractPages(chosen, t.trim(), d.folderId);
    sel.clear();
    if (id != null) toast('Split'.tr, 'New document created'.tr);
  }

  @override
  Widget build(BuildContext context) {
    final d = doc;
    if (d == null) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    final selecting = sel.isNotEmpty;
    return Scaffold(
      appBar: selecting
          ? AppBar(
              leading: IconButton(icon: const Icon(Icons.close), onPressed: () => setState(sel.clear)),
              title: Text('@n selected'.trParams({'n': '${sel.length}'})),
              actions: [
                IconButton(icon: const Icon(Icons.select_all), onPressed: () => setState(() => sel.addAll(pages.map((p) => p.id)))),
                IconButton(icon: const Icon(Icons.call_split), tooltip: 'Extract to new document'.tr, onPressed: () => _extract(d)),
                IconButton(
                    icon: const Icon(Icons.picture_as_pdf_outlined),
                    tooltip: 'Export selected as PDF'.tr,
                    onPressed: () => exportFlow(d, pages.where((p) => sel.contains(p.id)).toList())),
                IconButton(
                  icon: const Icon(Icons.delete_outline),
                  onPressed: () async {
                    if (await confirm('Delete pages'.tr, 'Delete @n page(s)?'.trParams({'n': '${sel.length}'}))) {
                      await dc.deletePages(pages.where((p) => sel.contains(p.id)).toList());
                      if (dc.docs.every((x) => x.id != d.id)) Get.back();
                    }
                  },
                ),
              ],
            )
          : AppBar(
              title: Text(d.title, overflow: TextOverflow.ellipsis),
              actions: [
                IconButton(icon: Icon(d.favorite ? Icons.star : Icons.star_border, color: d.favorite ? Colors.amber : null), onPressed: () => dc.toggleFavorite(d)),
                PopupMenuButton<String>(
                  onSelected: (v) => _more(v, d),
                  itemBuilder: (_) => [
                    PopupMenuItem(value: 'rename', child: Text('Rename'.tr)),
                    PopupMenuItem(value: 'tags', child: Text('Tags'.tr)),
                    PopupMenuItem(value: 'folder', child: Text('Move to folder'.tr)),
                    PopupMenuItem(value: 'lock', child: Text(d.locked ? 'Unlock document'.tr : 'Lock with PIN'.tr)),
                    PopupMenuItem(value: 'text', child: Text('Recognized text'.tr)),
                    PopupMenuItem(value: 'invoice', child: Text('Invoice data'.tr)),
                    PopupMenuItem(value: 'ocr', child: Text('Run OCR again'.tr)),
                    PopupMenuItem(value: 'export', child: Text('Export PDF'.tr)),
                    PopupMenuItem(value: 'word', child: Text('Export Word'.tr)),
                    PopupMenuItem(value: 'delete', child: Text('Delete document'.tr)),
                  ],
                ),
              ],
            ),
      body: pages.isEmpty
          ? const Center(child: CircularProgressIndicator())
          : ReorderableListView.builder(
              buildDefaultDragHandles: false,
              padding: const EdgeInsets.fromLTRB(8, 8, 8, 100),
              itemCount: pages.length,
              onReorder: (o, n) async {
                if (n > o) n--;
                final l = List.of(pages);
                final x = l.removeAt(o);
                l.insert(n, x);
                setState(() => pages = l);
                await dc.reorder(d.id, l);
              },
              itemBuilder: (_, i) {
                final p = pages[i];
                final selected = sel.contains(p.id);
                return Card(
                  key: ValueKey(p.id),
                  color: selected ? Theme.of(context).colorScheme.primaryContainer : null,
                  child: ListTile(
                    onTap: () {
                      if (selecting) {
                        setState(() => selected ? sel.remove(p.id) : sel.add(p.id));
                      } else {
                        Get.to(() => PageViewerView(docId: d.id, initial: i));
                      }
                    },
                    onLongPress: () => setState(() => sel.add(p.id)),
                    leading: ClipRRect(borderRadius: BorderRadius.circular(4), child: SizedBox(width: 56, height: 72, child: FileThumb(path: p.displayPath))),
                    title: Text('Page @n'.trParams({'n': '${i + 1}'})),
                    subtitle: Text(p.ocrText.isEmpty ? '${p.width}×${p.height}' : p.ocrText.replaceAll('\n', ' '), maxLines: 2, overflow: TextOverflow.ellipsis),
                    trailing: ReorderableDragStartListener(index: i, child: const Padding(padding: EdgeInsets.all(8), child: Icon(Icons.drag_handle))),
                  ),
                );
              },
            ),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(12, 4, 12, 8),
          child: Row(children: [
            Expanded(
              child: OutlinedButton.icon(
                icon: const Icon(Icons.add_a_photo_outlined),
                label: Text('Add pages'.tr),
                onPressed: () => Get.bottomSheet(
                  SafeArea(
                    child: Wrap(children: [
                      ListTile(leading: const Icon(Icons.document_scanner_outlined), title: Text('Scan with camera'.tr), onTap: () {
                        Get.back();
                        startScan(targetDoc: d.id);
                      }),
                      ListTile(leading: const Icon(Icons.photo_library_outlined), title: Text('Import images'.tr), onTap: () {
                        Get.back();
                        startImport(targetDoc: d.id);
                      }),
                      ListTile(leading: const Icon(Icons.picture_as_pdf_outlined), title: Text('Import PDF'.tr), onTap: () {
                        Get.back();
                        startPdfImport(targetDoc: d.id);
                      }),
                    ]),
                  ),
                  backgroundColor: Theme.of(context).colorScheme.surface,
                ),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: FilledButton.icon(
                icon: const Icon(Icons.picture_as_pdf),
                label: Text('PDF'.tr),
                onPressed: () => exportFlow(d, pages),
              ),
            ),
          ]),
        ),
      ),
    );
  }
}
