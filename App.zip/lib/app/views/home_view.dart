import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../controllers/app_controller.dart';
import 'documents_tab.dart';
import 'settings_view.dart';
import 'tools_view.dart';
import 'widgets/common.dart';

class HomeView extends StatefulWidget {
  const HomeView({super.key});
  @override
  State<HomeView> createState() => _HomeViewState();
}

class _HomeViewState extends State<HomeView> {
  int tab = 0;

  @override
  Widget build(BuildContext context) {
    final app = Get.find<AppController>();
    return Obx(() {
      if (app.hasPin.value && !app.sessionUnlocked.value) return const LockScreen();
      return Scaffold(
        body: IndexedStack(index: tab, children: const [DocumentsTab(), ToolsView(), SettingsView()]),
        bottomNavigationBar: NavigationBar(
          selectedIndex: tab,
          onDestinationSelected: (i) => setState(() => tab = i),
          destinations: [
            NavigationDestination(icon: const Icon(Icons.folder_copy_outlined), selectedIcon: const Icon(Icons.folder_copy), label: 'Documents'.tr),
            NavigationDestination(icon: const Icon(Icons.handyman_outlined), selectedIcon: const Icon(Icons.handyman), label: 'Tools'.tr),
            NavigationDestination(icon: const Icon(Icons.settings_outlined), selectedIcon: const Icon(Icons.settings), label: 'Settings'.tr),
          ],
        ),
      );
    });
  }
}
