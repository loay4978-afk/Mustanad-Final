import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../controllers/docs_controller.dart';
import '../core/storage.dart';
import '../core/utils.dart';
import '../data/db/app_db.dart';
import '../data/models/models.dart';
import '../engine/scanner_engine.dart';

/// عنصر تعليق: قلم / تظليل / نص / توقيع (إحداثيات طبيعية 0..1)
class Annot {
  String type; // pen | hl | text | sig
  List<double> pts;
  double width;
  int color;
  String text;
  String sig;
  double x, y, scale;

  Annot({
    required this.type,
    this.pts = const [],
    this.width = 0.006,
    this.color = 0xFF1565C0,
    this.text = '',
    this.sig = '',
    this.x = 0.5,
    this.y = 0.5,
    this.scale = 0.05,
  });

  Map<String, Object?> toJson() => {
        't': type,
        'p': pts,
        'w': width,
        'c': color,
        'x': text,
        's': sig,
        'px': x,
        'py': y,
        'sc': scale,
      };

  factory Annot.fromJson(Map<String, dynamic> j) => Annot(
        type: j['t'] as String,
        pts: ((j['p'] as List?) ?? []).map((e) => (e as num).toDouble()).toList(),
        width: ((j['w'] as num?) ?? 0.006).toDouble(),
        color: (j['c'] as int?) ?? 0xFF1565C0,
        text: (j['x'] as String?) ?? '',
        sig: (j['s'] as String?) ?? '',
        x: ((j['px'] as num?) ?? 0.5).toDouble(),
        y: ((j['py'] as num?) ?? 0.5).toDouble(),
        scale: ((j['sc'] as num?) ?? 0.05).toDouble(),
      );
}

class AnnotPainter extends CustomPainter {
  final List<Annot> items;
  final Map<String, ui.Image> sigs;
  final Annot? selected;
  AnnotPainter(this.items, this.sigs, {this.selected});

  static bool _isArabic(String s) => RegExp(r'[\u0600-\u06FF]').hasMatch(s);

  @override
  void paint(Canvas canvas, Size size) {
    for (final a in items) {
      switch (a.type) {
        case 'pen':
        case 'hl':
          final paint = Paint()
            ..color = Color(a.color)
            ..style = PaintingStyle.stroke
            ..strokeCap = a.type == 'hl' ? StrokeCap.butt : StrokeCap.round
            ..strokeJoin = StrokeJoin.round
            ..strokeWidth = a.width * size.width;
          if (a.type == 'hl') paint.blendMode = BlendMode.multiply;
          if (a.pts.length >= 4) {
            final path = Path()..moveTo(a.pts[0] * size.width, a.pts[1] * size.height);
            for (var i = 2; i + 1 < a.pts.length; i += 2) {
              path.lineTo(a.pts[i] * size.width, a.pts[i + 1] * size.height);
            }
            canvas.drawPath(path, paint);
          } else if (a.pts.length >= 2) {
            canvas.drawCircle(Offset(a.pts[0] * size.width, a.pts[1] * size.height), paint.strokeWidth / 2,
                Paint()..color = Color(a.color));
          }
          break;
        case 'text':
          final tp = TextPainter(
            text: TextSpan(text: a.text, style: TextStyle(color: Color(a.color), fontSize: a.scale * size.width, fontWeight: FontWeight.w500)),
            textDirection: _isArabic(a.text) ? TextDirection.rtl : TextDirection.ltr,
          )..layout(maxWidth: size.width * 0.9);
          final off = Offset(a.x * size.width - tp.width / 2, a.y * size.height - tp.height / 2);
          tp.paint(canvas, off);
          if (identical(a, selected)) {
            canvas.drawRect(off & tp.size, Paint()..color = Colors.blueAccent..style = PaintingStyle.stroke..strokeWidth = 2);
          }
          break;
        case 'sig':
          final img = sigs[a.sig];
          if (img == null) break;
          final w = a.scale * size.width;
          final h = w * img.height / img.width;
          final rect = Rect.fromCenter(center: Offset(a.x * size.width, a.y * size.height), width: w, height: h);
          canvas.drawImageRect(img, Rect.fromLTWH(0, 0, img.width.toDouble(), img.height.toDouble()), rect,
              Paint()..filterQuality = FilterQuality.medium);
          if (identical(a, selected)) {
            canvas.drawRect(rect, Paint()..color = Colors.blueAccent..style = PaintingStyle.stroke..strokeWidth = 2);
          }
          break;
      }
    }
  }

  @override
  bool shouldRepaint(covariant AnnotPainter old) => true;
}

class AnnotateView extends StatefulWidget {
  final PageModel page;
  const AnnotateView({super.key, required this.page});
  @override
  State<AnnotateView> createState() => _AnnotateViewState();
}

class _AnnotateViewState extends State<AnnotateView> {
  final dc = Get.find<DocsController>();
  ui.Image? base;
  final items = <Annot>[];
  final sigs = <String, ui.Image>{};
  String tool = 'pen'; // pen | hl | text | sig | move
  int color = 0xFF1565C0;
  double thickness = 1.0;
  Annot? selected;
  String? activeSig;
  bool saving = false;

  static const colors = [0xFF1565C0, 0xFFD32F2F, 0xFF2E7D32, 0xFF000000, 0xFFFFEB3B, 0xFFFF9800];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<ui.Image> _decode(String path) async => decodeImageFromList(await File(path).readAsBytes());

  Future<void> _load() async {
    final img = await _decode(widget.page.procPath);
    final list = (jsonDecode(widget.page.annotations) as List).map((e) => Annot.fromJson(e as Map<String, dynamic>)).toList();
    for (final a in list) {
      if (a.type == 'sig' && File(a.sig).existsSync()) sigs[a.sig] = await _decode(a.sig);
    }
    if (!mounted) return;
    setState(() {
      base = img;
      items.addAll(list);
    });
  }

  double get _penWidth => (tool == 'hl' ? 0.03 : 0.005) * thickness;

  void _down(Offset p, Size s) async {
    final n = Offset(p.dx / s.width, p.dy / s.height);
    if (tool == 'pen' || tool == 'hl') {
      setState(() {
        selected = null;
        items.add(Annot(type: tool, pts: [n.dx, n.dy], width: _penWidth, color: tool == 'hl' ? (color == 0xFF1565C0 ? 0xFFFFEB3B : color) : color));
      });
    } else if (tool == 'text') {
      final t = await askText('Comment text'.tr);
      if (t != null && t.trim().isNotEmpty) {
        setState(() {
          final a = Annot(type: 'text', text: t.trim(), x: n.dx, y: n.dy, color: color, scale: 0.04 * thickness);
          items.add(a);
          selected = a;
        });
      }
    } else if (tool == 'sig') {
      if (activeSig == null) {
        await _pickSignature();
        if (activeSig == null) return;
      }
      setState(() {
        final a = Annot(type: 'sig', sig: activeSig!, x: n.dx, y: n.dy, scale: 0.28 * thickness);
        items.add(a);
        selected = a;
      });
    } else if (tool == 'move') {
      Annot? best;
      var bd = 0.12;
      for (final a in items) {
        if (a.type != 'text' && a.type != 'sig') continue;
        final d = (Offset(a.x, a.y) - n).distance;
        if (d < bd) {
          bd = d;
          best = a;
        }
      }
      setState(() => selected = best);
    }
  }

  void _move(Offset p, Size s) {
    final n = Offset((p.dx / s.width).clamp(0.0, 1.0), (p.dy / s.height).clamp(0.0, 1.0));
    if ((tool == 'pen' || tool == 'hl') && items.isNotEmpty) {
      setState(() => items.last.pts = [...items.last.pts, n.dx, n.dy]);
    } else if (tool == 'move' && selected != null) {
      setState(() {
        selected!.x = n.dx;
        selected!.y = n.dy;
      });
    }
  }

  Future<void> _pickSignature() async {
    final db = AppDb.instance;
    final list = await db.getSignatures();
    final r = await Get.bottomSheet<String>(
      SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(
            leading: const Icon(Icons.add),
            title: Text('Draw a new signature'.tr),
            onTap: () async {
              final path = await Get.dialog<String>(const _SignaturePad());
              Get.back(result: path);
            },
          ),
          for (final s in list)
            ListTile(
              leading: SizedBox(width: 90, child: Image.file(File(s['path'] as String), fit: BoxFit.contain)),
              title: Text('Saved signature'.tr),
              trailing: IconButton(
                icon: const Icon(Icons.delete_outline),
                onPressed: () async {
                  await db.deleteSignature(s['id'] as int);
                  Storage.deleteQuiet(s['path'] as String);
                  Get.back();
                },
              ),
              onTap: () => Get.back(result: s['path'] as String),
            ),
        ]),
      ),
      backgroundColor: Theme.of(context).colorScheme.surface,
    );
    if (r != null && File(r).existsSync()) {
      sigs[r] = await _decode(r);
      setState(() => activeSig = r);
    }
  }

  Future<void> _save() async {
    final b = base;
    if (b == null) return;
    setState(() => saving = true);
    try {
      if (items.isEmpty) {
        await dc.saveAnnotated(widget.page, '[]', null);
      } else {
        final w = b.width, h = b.height;
        final rec = ui.PictureRecorder();
        final canvas = Canvas(rec);
        canvas.drawImage(b, Offset.zero, Paint());
        AnnotPainter(items, sigs).paint(canvas, Size(w.toDouble(), h.toDouble()));
        final pic = rec.endRecording();
        final im = await pic.toImage(w, h);
        final bd = await im.toByteData(format: ui.ImageByteFormat.rawRgba);
        final jpeg = await compute<Map<String, Object?>, Uint8List>(
            encodeRgbaEntry, {'rgba': bd!.buffer.asUint8List(), 'w': w, 'h': h, 'quality': 92});
        await dc.saveAnnotated(widget.page, jsonEncode(items.map((a) => a.toJson()).toList()), jpeg);
      }
      Get.back();
    } catch (e) {
      toast('Error'.tr, 'Could not save'.tr, error: true);
      if (mounted) setState(() => saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final b = base;
    return Scaffold(
      appBar: AppBar(
        title: Text('Annotate and sign'.tr),
        actions: [
          IconButton(
            icon: const Icon(Icons.undo),
            onPressed: items.isEmpty ? null : () => setState(() {
                  final a = items.removeLast();
                  if (identical(a, selected)) selected = null;
                }),
          ),
          saving
              ? const Padding(padding: EdgeInsets.all(14), child: SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)))
              : IconButton(icon: const Icon(Icons.check), onPressed: _save),
        ],
      ),
      body: b == null
          ? const Center(child: CircularProgressIndicator())
          : Column(children: [
              Expanded(
                child: Container(
                  color: Colors.black12,
                  alignment: Alignment.center,
                  child: AspectRatio(
                    aspectRatio: b.width / b.height,
                    child: LayoutBuilder(builder: (ctx, cons) {
                      final size = Size(cons.maxWidth, cons.maxHeight);
                      return GestureDetector(
                        onPanStart: (d) => _down(d.localPosition, size),
                        onPanUpdate: (d) => _move(d.localPosition, size),
                        onTapUp: (d) {
                          if (tool == 'text' || tool == 'sig' || tool == 'move') _down(d.localPosition, size);
                        },
                        child: Stack(fit: StackFit.expand, children: [
                          RawImage(image: b, fit: BoxFit.fill),
                          CustomPaint(painter: AnnotPainter(items, sigs, selected: selected)),
                        ]),
                      );
                    }),
                  ),
                ),
              ),
              Container(
                color: Theme.of(context).colorScheme.surface,
                child: SafeArea(
                  top: false,
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
                      for (final t in [
                        ['pen', Icons.edit, 'Pen'],
                        ['hl', Icons.border_color, 'Highlight'],
                        ['text', Icons.text_fields, 'Text'],
                        ['sig', Icons.gesture, 'Signature'],
                        ['move', Icons.open_with, 'Move'],
                      ])
                        InkWell(
                          onTap: () => setState(() => tool = t[0] as String),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 10),
                            child: Column(mainAxisSize: MainAxisSize.min, children: [
                              Icon(t[1] as IconData, color: tool == t[0] ? Theme.of(context).colorScheme.primary : null),
                              Text((t[2] as String).tr, style: TextStyle(fontSize: 11, color: tool == t[0] ? Theme.of(context).colorScheme.primary : null)),
                            ]),
                          ),
                        ),
                    ]),
                    Row(children: [
                      const SizedBox(width: 12),
                      for (final c in colors)
                        GestureDetector(
                          onTap: () => setState(() {
                            color = c;
                            if (selected != null && selected!.type == 'text') selected!.color = c;
                          }),
                          child: Container(
                            width: 26,
                            height: 26,
                            margin: const EdgeInsets.symmetric(horizontal: 4),
                            decoration: BoxDecoration(
                              color: Color(c),
                              shape: BoxShape.circle,
                              border: Border.all(color: color == c ? Colors.black : Colors.black26, width: color == c ? 3 : 1),
                            ),
                          ),
                        ),
                      Expanded(
                        child: Slider(
                          value: thickness,
                          min: 0.5,
                          max: 3,
                          onChanged: (v) => setState(() {
                            thickness = v;
                            final s = selected;
                            if (s != null && s.type == 'text') s.scale = 0.04 * v;
                            if (s != null && s.type == 'sig') s.scale = 0.28 * v;
                          }),
                        ),
                      ),
                    ]),
                  ]),
                ),
              ),
            ]),
    );
  }
}

/// لوحة رسم التوقيع: تُحفظ كصورة PNG شفافة مقصوصة على حدود التوقيع
class _SignaturePad extends StatefulWidget {
  const _SignaturePad();
  @override
  State<_SignaturePad> createState() => _SignaturePadState();
}

class _SignaturePadState extends State<_SignaturePad> {
  final strokes = <List<Offset>>[];

  Future<void> _save() async {
    final pts = strokes.expand((s) => s).toList();
    if (pts.isEmpty) return;
    var minX = pts.first.dx, maxX = pts.first.dx, minY = pts.first.dy, maxY = pts.first.dy;
    for (final p in pts) {
      minX = math.min(minX, p.dx);
      maxX = math.max(maxX, p.dx);
      minY = math.min(minY, p.dy);
      maxY = math.max(maxY, p.dy);
    }
    const pad = 8.0, k = 3.0;
    final w = ((maxX - minX + pad * 2) * k).ceil().clamp(60, 4000);
    final h = ((maxY - minY + pad * 2) * k).ceil().clamp(40, 4000);
    final rec = ui.PictureRecorder();
    final canvas = Canvas(rec);
    final paint = Paint()
      ..color = const Color(0xFF0D2A6B)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.6 * k
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;
    for (final s in strokes) {
      final path = Path();
      for (var i = 0; i < s.length; i++) {
        final o = Offset((s[i].dx - minX + pad) * k, (s[i].dy - minY + pad) * k);
        if (i == 0) {
          path.moveTo(o.dx, o.dy);
          if (s.length == 1) path.lineTo(o.dx + 0.1, o.dy);
        } else {
          path.lineTo(o.dx, o.dy);
        }
      }
      canvas.drawPath(path, paint);
    }
    final im = await rec.endRecording().toImage(w, h);
    final bd = await im.toByteData(format: ui.ImageByteFormat.png);
    final path = await Storage.newPath('signatures', 'png');
    await File(path).writeAsBytes(bd!.buffer.asUint8List());
    await AppDb.instance.insertSignature(path);
    Get.back(result: path);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text('Draw your signature'.tr),
      content: Container(
        width: 300,
        height: 160,
        decoration: BoxDecoration(color: Colors.white, border: Border.all(color: Colors.black38), borderRadius: BorderRadius.circular(8)),
        child: GestureDetector(
          onPanStart: (d) => setState(() => strokes.add([d.localPosition])),
          onPanUpdate: (d) => setState(() => strokes.last.add(d.localPosition)),
          child: ClipRect(child: CustomPaint(painter: _PadPainter(strokes), size: Size.infinite)),
        ),
      ),
      actions: [
        TextButton(onPressed: () => setState(strokes.clear), child: Text('Clear'.tr)),
        TextButton(onPressed: () => Get.back(), child: Text('Cancel'.tr)),
        FilledButton(onPressed: _save, child: Text('Save'.tr)),
      ],
    );
  }
}

class _PadPainter extends CustomPainter {
  final List<List<Offset>> strokes;
  _PadPainter(this.strokes);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF0D2A6B)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.6
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;
    for (final s in strokes) {
      if (s.length < 2) {
        if (s.isNotEmpty) canvas.drawCircle(s.first, 1.3, Paint()..color = const Color(0xFF0D2A6B));
        continue;
      }
      final path = Path()..moveTo(s[0].dx, s[0].dy);
      for (var i = 1; i < s.length; i++) {
        path.lineTo(s[i].dx, s[i].dy);
      }
      canvas.drawPath(path, paint);
    }
  }

  @override
  bool shouldRepaint(covariant _PadPainter old) => true;
}
