import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:path/path.dart' as p;

import '../controllers/app_controller.dart';
import '../controllers/tools_controller.dart';
import '../core/ocr_service.dart';
import '../core/utils.dart';
import '../data/models/models.dart';
import 'file_result.dart';

class _WordOptions {
  final String mode;
  final List<String> langs;
  final String title;
  _WordOptions(this.mode, this.langs, this.title);
}

Future<_WordOptions?> _askOptions(String initialTitle) async {
  final app = Get.find<AppController>();
  var mode = 'editable';
  final langs = <String>{...app.ocrLangs};
  final tctrl = TextEditingController(text: initialTitle);
  final ok = await Get.dialog<bool>(StatefulBuilder(
    builder: (ctx, setState) => AlertDialog(
      title: Text('Convert to Word'.tr),
      content: SingleChildScrollView(
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          TextField(controller: tctrl, decoration: InputDecoration(labelText: 'Output name'.tr)),
          const SizedBox(height: 14),
          Text('Word layout'.tr, style: const TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          Wrap(spacing: 8, children: [
            ChoiceChip(label: Text('Editable text'.tr), selected: mode == 'editable', onSelected: (_) => setState(() => mode = 'editable')),
            ChoiceChip(label: Text('Exact copy (page images)'.tr), selected: mode == 'exact', onSelected: (_) => setState(() => mode = 'exact')),
          ]),
          const SizedBox(height: 6),
          Text(
            mode == 'editable'
                ? 'Text is recognized and rebuilt with paragraphs, alignment, text direction, font sizes and bold. Tables and pictures are not rebuilt.'.tr
                : 'Every page is placed as an image, so the look is identical but the text is not editable.'.tr,
            style: Theme.of(ctx).textTheme.bodySmall,
          ),
          if (mode == 'editable') ...[
            const SizedBox(height: 14),
            Text('OCR languages'.tr, style: const TextStyle(fontWeight: FontWeight.bold)),
            Wrap(spacing: 8, children: [
              for (final e in OcrService.languages.entries)
                FilterChip(
                  label: Text(e.value),
                  selected: langs.contains(e.key),
                  onSelected: (v) => setState(() => v ? langs.add(e.key) : langs.remove(e.key)),
                ),
            ]),
          ],
        ]),
      ),
      actions: [
        TextButton(onPressed: () => Get.back(result: false), child: Text('Cancel'.tr)),
        FilledButton(onPressed: () => Get.back(result: true), child: Text('Convert'.tr)),
      ],
    ),
  ));
  if (ok != true) return null;
  final t = tctrl.text.trim().isEmpty ? 'document' : tctrl.text.trim();
  return _WordOptions(mode, langs.isEmpty ? ['eng'] : langs.toList(), t);
}

const _wordNote = 'Open the file in Word and review the result: scanned text can contain recognition mistakes.';

/// تحويل ملف PDF خارجي إلى Word
Future<void> pdfToWordFlow() async {
  final r = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['pdf']);
  final path = r?.files.single.path;
  if (path == null) return;
  final o = await _askOptions(p.basenameWithoutExtension(path));
  if (o == null) return;
  final progress = 0.obs;
  final File? f = await runWithProgress<File>('Converting…'.tr, progress, () => Get.find<ToolsController>().pdfFileToWord(path, o.title, o.mode, o.langs, progress: progress));
  if (f != null) await showFileResult([f], note: _wordNote.tr, shareText: o.title);
}

/// تحويل مستند من داخل التطبيق إلى Word
Future<void> docToWordFlow(DocModel d, List<PageModel> pages) async {
  if (pages.isEmpty) return;
  final o = await _askOptions(d.title);
  if (o == null) return;
  final progress = 0.obs;
  final File? f = await runWithProgress<File>('Converting…'.tr, progress, () => Get.find<ToolsController>().docToWord(d, pages, o.mode, o.langs, progress: progress));
  if (f != null) await showFileResult([f], note: _wordNote.tr, shareText: o.title);
}
